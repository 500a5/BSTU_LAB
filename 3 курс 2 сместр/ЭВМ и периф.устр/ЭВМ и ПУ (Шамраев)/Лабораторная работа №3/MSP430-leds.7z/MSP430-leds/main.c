#include <msp430.h> 
#include "system_define.h"
#include "system_variable.h"
#include "function_prototype.h"
#include "I2C.h"
#include "main.h"

/*
 * main.c
 */

void main(void) {
    _enable_interrupt();
    WDTCTL = WDTPW+WDTHOLD; // Отключить сторожевой таймер
    Init_System_Clock();    // Запустить тактирование
    Init_System();          // Настройка портов, итд
    Init_I2C();             // Настройка I2C
    LED_clear();            // Очистка дисплея
    char key;
    int f = 0;
    // Цикл продолжается, пока не введется символ *
    while (f != 1) {
        key = KEYS_scannow();
        switch (key) {
        case '5':
            LED_clear();
            LED_set(5);
            break;
        case '7':
            LED_clear();
            LED_set(6);
            break;
        case '9':
            LED_clear();
            LED_set(7);
            break;
        case '*':
            f = 1;
        }
    }
    // * - выход из цикла опроса
    while(1){
    }
}

