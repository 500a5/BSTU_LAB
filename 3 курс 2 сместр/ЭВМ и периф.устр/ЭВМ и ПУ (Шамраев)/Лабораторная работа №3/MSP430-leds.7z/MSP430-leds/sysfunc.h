#ifndef __SYSFUNC_H__
#define __SYSFUNC_H__
#include "system_define.h"

extern word wait_i, wait_j;

#endif
