//---------------------------------------------------------------------------
#ifndef __I2C_H__
#define __I2C_H__

extern byte Tx_Data[], Rx_Data[];
extern byte *BufTptr, *BufRptr;
#endif
