﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;


namespace bddddd.DBClass
{
    class AchieveDB
    {
        public List<string[]> selectAll()
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT ID, Title, Point FROM Achievement";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[3]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }
        
        //=====EntrantAchieve
        public List<string[]> selectByEntrant(int id)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT EA.IDAchieve, EA.IDEntrant 
                                FROM EntrantAchiv AS EA, Entrant AS E, Achievement as A
                                WHERE E.ID = EA.IDEntrant AND E.ID = @nn AND A.ID = EA.IDAchieve";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("nn", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[2]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        //lst[lst.Count - 1][2] = reader[2].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //=====EntrantAchieve
        public List<string[]> selectByEntrant2(int id)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT EA.IDAchieve, EA.IDEntrant, A.Title, A.Point 
                                FROM EntrantAchiv AS EA, Entrant AS E, Achievement as A
                                WHERE E.ID = EA.IDEntrant AND E.ID = @nn AND A.ID = EA.IDAchieve";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("nn", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[4]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                        lst[lst.Count - 1][3] = reader[3].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        public bool insertIntoByEntrant(int entr, int achiv)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO EntrantAchiv (IDEntrant, IDAchieve) VALUES(@IDE, @IDA)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("IDE", entr);
                    cmd.Parameters.AddWithValue("IDA", achiv);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }
        
        public bool deleteFromByEntrant(int idEntrant, int idAch)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM EntrantAchiv WHERE IDAchieve = @id AND IDEntrant = @ide";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("id", idAch);
                    cmd.Parameters.AddWithValue("ide", idEntrant);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        public bool deleteFrom(int idAch)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Achievement WHERE ID = @id";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("id", idAch);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        public bool insertInto(string s, int point)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO  Achievement (Title, Point) VALUES(@IDE, @IDA)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("IDE", s);
                    cmd.Parameters.AddWithValue("IDA", point);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        public bool updateInfo(int idAchive, string name, int pointt)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Achievement SET Point = @pi, Title = @ti WHERE ID = @id";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("pi", pointt);
                    cmd.Parameters.AddWithValue("ti", name);
                    cmd.Parameters.AddWithValue("id", idAchive);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //если имя ачивки совпадает с именем из запроса, вернуть ее id
        public int searchId(string s)
        {
            //ID, Title, Point
            List<string[]> lst2 = this.selectAll();
            for (int i = 0; i < lst2.Count; i++)
            {
                if (lst2[i][1] == s)
                    return Int32.Parse(lst2[i][0]);
            }
            return -1;
        }

    }
}
