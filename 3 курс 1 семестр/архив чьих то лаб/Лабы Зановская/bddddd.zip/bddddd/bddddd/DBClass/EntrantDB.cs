﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class EntrantDB
    {
        //Получить список абиков
        public List<string[]> selectAll()
        {
            List<string[]> lst2 = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT * FROM Entrant";
                    //ид фамилия имя отчество паспорт адрес дата рождения контакт образование общага
                    SqlCommand cmd = new SqlCommand(str, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst2.Add(new string[10]);
                        lst2[lst2.Count - 1][0] = reader[0].ToString();
                        lst2[lst2.Count - 1][1] = reader[1].ToString();
                        lst2[lst2.Count - 1][2] = reader[2].ToString();
                        lst2[lst2.Count - 1][3] = reader[3].ToString();
                        lst2[lst2.Count - 1][4] = reader[4].ToString();
                        lst2[lst2.Count - 1][5] = reader[5].ToString();
                        lst2[lst2.Count - 1][6] = reader[6].ToString();
                        lst2[lst2.Count - 1][7] = reader[7].ToString();
                        lst2[lst2.Count - 1][8] = reader[8].ToString();
                        lst2[lst2.Count - 1][9] = reader[9].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst2;
        }

        //Получить абика
        public List<string[]> selectOne(int id)
        {
            List<string[]> lst2 = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT * FROM Entrant WHERE ID = @ide";
                    //ид фамилия имя отчество паспорт адрес дата рождения контакт образование общага
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ide", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst2.Add(new string[10]);
                        lst2[lst2.Count - 1][0] = reader[0].ToString();
                        lst2[lst2.Count - 1][1] = reader[1].ToString();
                        lst2[lst2.Count - 1][2] = reader[2].ToString();
                        lst2[lst2.Count - 1][3] = reader[3].ToString();
                        lst2[lst2.Count - 1][4] = reader[4].ToString();
                        lst2[lst2.Count - 1][5] = reader[5].ToString();
                        lst2[lst2.Count - 1][6] = reader[6].ToString();
                        lst2[lst2.Count - 1][7] = reader[7].ToString();
                        lst2[lst2.Count - 1][8] = reader[8].ToString();
                        lst2[lst2.Count - 1][9] = reader[9].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst2;
        }

        //Удалить из абитуриента
        public bool deleteFrom(int entr)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Entrant WHERE ID = @id";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("id", entr);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return false;
        }

        //добавление
        public int insertIntoPatron(string surnam, string name, string patron, string passp, string adre, DateTimePicker birth, string cont, string pred, bool host)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str;
                    str = @"INSERT INTO Entrant 
                        (Surname, Iname, Patronymic, Passport, Adress, 
                        BirthDate, Contact, PreviousEducation, Hostel) 
                        VALUES (@Sr, @Na, @Pa, @Pas, @Adr, @Bd, @Con, @PE, @Hos)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("Sr", surnam);
                    cmd.Parameters.AddWithValue("Na", name);
                    cmd.Parameters.AddWithValue("Pa", patron);
                    cmd.Parameters.AddWithValue("Pas", passp);
                    cmd.Parameters.AddWithValue("Adr", adre);
                    cmd.Parameters.AddWithValue("Bd", birth.Value);
                    cmd.Parameters.AddWithValue("Con", cont);
                    cmd.Parameters.AddWithValue("Pe", pred);
                    cmd.Parameters.AddWithValue("Hos", host);
                    cmd.ExecuteNonQuery();
                    SqlCommand cmd2 = new SqlCommand("SELECT @@IDENTITY AS [IDENTITY]", conn);
                    object result = cmd2.ExecuteScalar();
                    result = (result == DBNull.Value) ? null : result;
                    int countDis = Convert.ToInt32(result);
                    conn.Close();
                    return countDis;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return -1;
        }

        //добавление
        public int insertIntoNoPatron(string surnam, string name, string passp, string adre, DateTimePicker birth, string cont, string pred, bool host)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str;
                    str = @"INSERT INTO Entrant 
                        (Surname, Iname, Passport, Adress, 
                        BirthDate, Contact, PreviousEducation, Hostel) 
                        VALUES (@Sr, @Na, @Pas, @Adr, @Bd, @Con, @PE, @Hos)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("Sr", surnam);
                    cmd.Parameters.AddWithValue("Na", name);
                    cmd.Parameters.AddWithValue("Pas", passp);
                    cmd.Parameters.AddWithValue("Adr", adre);
                    cmd.Parameters.AddWithValue("Bd", birth.Value);
                    cmd.Parameters.AddWithValue("Con", cont);
                    cmd.Parameters.AddWithValue("Pe", pred);
                    cmd.Parameters.AddWithValue("Hos", host);
                    cmd.ExecuteNonQuery();
                    SqlCommand cmd2 = new SqlCommand("SELECT @@IDENTITY AS [IDENTITY]", conn);
                    object result = cmd2.ExecuteScalar();
                    result = (result == DBNull.Value) ? null : result;
                    int countDis = Convert.ToInt32(result);
                    conn.Close();
                    return countDis;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return -1;
        }

        //обнов
        public bool updateIfoPATRON(string surnam, string name, string patron, string passp, string adre, DateTimePicker birth, string cont, string pred, bool host, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str;
                    str = @"UPDATE Entrant SET 
                        Surname = @Sr, Iname = @Na, Patronymic = @Pa, 
                        Passport = @Pas, Adress = @Adr, BirthDate = @Bd, 
                        Contact = @Con, PreviousEducation = @Pe, Hostel = @Hos 
                        WHERE ID = @nn";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("Sr", surnam);
                    cmd.Parameters.AddWithValue("Na", name);
                    cmd.Parameters.AddWithValue("Pa", patron);
                    cmd.Parameters.AddWithValue("Pas", passp);
                    cmd.Parameters.AddWithValue("Adr", adre);
                    cmd.Parameters.AddWithValue("Bd", birth.Value);
                    cmd.Parameters.AddWithValue("Con", cont);
                    cmd.Parameters.AddWithValue("Pe", pred);
                    cmd.Parameters.AddWithValue("Hos", host);
                    cmd.Parameters.AddWithValue("nn", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return false;
        }

        //обнов
        public bool updateIfoNOPATRON(string surnam, string name, string passp, string adre, DateTimePicker birth, string cont, string pred, bool host, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str;
                    str = @"UPDATE Entrant SET 
                            Surname = @Sr, Iname = @Na, Passport = @Pas, Adress = @Adr,     
                            BirthDate = @Bd, Contact = @Con, PreviousEducation = @Pe, Hostel = @Hos 
                            WHERE ID = @nn";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("Sr", surnam);
                    cmd.Parameters.AddWithValue("Na", name);
                    cmd.Parameters.AddWithValue("Pas", passp);
                    cmd.Parameters.AddWithValue("Adr", adre);
                    cmd.Parameters.AddWithValue("Bd", birth.Value);
                    cmd.Parameters.AddWithValue("Con", cont);
                    cmd.Parameters.AddWithValue("Pe", pred);
                    cmd.Parameters.AddWithValue("Hos", host);
                    cmd.Parameters.AddWithValue("nn", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return false;
        }
    }
}

/*/*
 * DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);

                    conn.Close();
                    //return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                //return false;
            }
     */