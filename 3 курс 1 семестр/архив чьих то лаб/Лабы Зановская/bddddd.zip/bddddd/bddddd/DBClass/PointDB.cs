﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;


namespace bddddd.DBClass
{
    class PointDB
    {
        //Получение баллы абитуриента по предметам
        public List<string[]> selectByEntrant(int id)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT E.ID, D.ID, D.Title, P.Point 
                        FROM Entrant AS E, Point AS P, Discipline AS D 
                        WHERE D.ID = P.IDDiscipline AND E.ID = P.IDEntrant AND E.ID = @nn";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("nn", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[4]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                        lst[lst.Count - 1][3] = reader[3].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //-1, если у абитуриента нет такого предмета, иначе его баллы
        public int searchhPointInEntrant(int idEntr, int idDisc)
        {
            //E.ID, D.ID, D.Title, P.Point 
            List<string[]> lst = this.selectByEntrant(idEntr); //нашли инфу о всех предметах абика
            for (int i = 0; i < lst.Count; i++)
            {
                int j = Int32.Parse(lst[i][1]);
                if (j == idDisc)
                {
                    return Int32.Parse(lst[i][3]);
                }
            }
            return -1;
        }

        //Добавить информацию 
        public bool insertInto(int idD, int idE, int poi)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO Point (IDDiscipline, IDENtrant, Point) VALUES(@IDD, @IDE, @P)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("IDD", idD);
                    cmd.Parameters.AddWithValue("IDE", idE);
                    cmd.Parameters.AddWithValue("P", poi);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Добавить информацию 
        public bool updateInfo(int idD, int idE, int poi)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Point SET Point = @P WHERE IDDiscipline = @IDD AND IDENtrant = @IDE";
//                    string str = @"INSERT INTO Point (IDDiscipline, IDENtrant, Point) VALUES(@IDD, @IDE, @P)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("IDD", idD);
                    cmd.Parameters.AddWithValue("IDE", idE);
                    cmd.Parameters.AddWithValue("P", poi);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Удалить из абитуриента
        public bool deleteFrom(int idD, int idE)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Point WHERE IDDiscipline = @IDD AND IDENtrant = @IDE";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("IDD", idD);
                    cmd.Parameters.AddWithValue("IDE", idE);
                    
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return false;
        }
    }
}
