﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class FormBasisTraningDB
    {
        //Основы обучения
        public List<string[]> selectBasis()
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT ID, Title FROM BasisTraning";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[2]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //Основы обучения
        public List<string[]> selectBasisBySpec(int idSpec)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT DISTINCT BT.ID, BT.Title   
                                    FROM BasisTraning AS BT, Places AS P WHERE P.IDBasisTraning = BT.ID AND 
                                    P.IDSpeciality =  @id ";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("id",idSpec);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[2]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //Основы обучения
        public List<string[]> selectFormBySpec(int idSpec)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT DISTINCT BT.ID, BT.Title 
                                   FROM FormTraning AS BT, Places AS P WHERE P.IDFormTraning = BT.ID AND 
                                   P.IDSpeciality =  @id ";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("id", idSpec);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[2]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //Формы
        public List<string[]> selectForm()
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT ID, Title FROM FormTraning";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[2]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //Возвращает 
        public int searchForm(string s)
        {
            List<string[]> lst = this.selectForm();
            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i][1] == s)
                    return Int32.Parse(lst[i][0]);
            }
            return -1;
        }

        //Возвращает 
        public int searchBasis(string s)
        {
            List<string[]> lst = this.selectBasis();
            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i][1] == s)
                    return Int32.Parse(lst[i][0]);
            }
            return -1;
        }

    }
}
/*
 * DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);

                    conn.Close();
                    //return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                //return false;
            }
     */
