﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class DBConn
    {
        public void OpenConn(SqlConnectionStringBuilder sb, SqlConnection conn)
        {
            try
            {
                sb.DataSource = "DESKTOP-6637QU0";                                                         //sb.DataSource = "DESKTOP-541C0P8\\SQL_SERVER";
                sb.InitialCatalog = "BratckovaPV31Comission";
                sb.IntegratedSecurity = true;
                conn.ConnectionString = sb.ConnectionString;
                conn.Open();
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Соединение не установлено", "Ошибка!");
            }

        }
    }
}
