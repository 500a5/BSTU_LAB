﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class PlacesDB
    {
        //Удалить запись о местах
        public bool deletFrom(int sp, int ft, int bt)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Places WHERE IDSpeciality = @ids AND IDFormTraning = @idf AND IDBasisTraning = @idb";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ids", sp);
                    cmd.Parameters.AddWithValue("idf", ft);
                    cmd.Parameters.AddWithValue("idb", bt);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Добавить информацию о местах по специальности форме и оснвое обучения
        public bool insertInto(int spec, int ft, int bt, int numb)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO Places (IDSpeciality, IDFormTraning, IDBasisTraning, NumberPlaces) VALUES(@ids, @idf, @idb, @num)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ids", spec);
                    cmd.Parameters.AddWithValue("idf", ft);
                    cmd.Parameters.AddWithValue("idb", bt);
                    cmd.Parameters.AddWithValue("num", numb);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Обновить инфо о местах
        public bool updateInfoNUMB(int spec, int ft, int bt, int numb)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = "UPDATE Places SET NumberPlaces = @ti WHERE IDFormTraning = @idf AND IDSpeciality = @ids AND IDBasisTraning = @idb";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ids", spec);
                    cmd.Parameters.AddWithValue("idf", ft);
                    cmd.Parameters.AddWithValue("idb", bt);
                    cmd.Parameters.AddWithValue("ti", numb);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Обновить инфо о местах
        public bool updateInfoFORMTRANING(int spec, int ft, int bt, int numb)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = "UPDATE Places SET IDFormTraning = @idf WHERE NumberPlaces = @ti AND IDSpeciality = @ids AND IDBasisTraning = @idb";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ids", spec);
                    cmd.Parameters.AddWithValue("idf", ft);
                    cmd.Parameters.AddWithValue("idb", bt);
                    cmd.Parameters.AddWithValue("ti", numb);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Обновить инфо о местах
        public bool updateInfoBASISTRANING(int spec, int ft, int bt, int numb)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = "UPDATE Places SET IDBasisTraning = @idb WHERE NumberPlaces = @ti AND IDSpeciality = @ids AND IDFormTraning = @idf ";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ids", spec);
                    cmd.Parameters.AddWithValue("idf", ft);
                    cmd.Parameters.AddWithValue("idb", bt);
                    cmd.Parameters.AddWithValue("ti", numb);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Выбрать всинформацию о местах по опр. спец
        public List<string[]> selectAll(int id)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT DISTINCT
                            F.ID, B.ID, P.IDSpeciality, F.Title, B.Title, P.NumberPlaces
                            FROM Places as P, Speciality as S, FormTraning as F,BasisTraning as B
                            WHERE P.IDBasisTraning = B.ID AND F.ID = P.IDFormTraning AND P.IDSpeciality = @idd";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("idd", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[6]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                        lst[lst.Count - 1][3] = reader[3].ToString();
                        lst[lst.Count - 1][4] = reader[4].ToString();
                        lst[lst.Count - 1][5] = reader[5].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //Выбрать всинформацию о местах по опр. спец
        public List<string[]> selectAll2(int id)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT DISTINCT
                            F.ID, B.ID, P.IDSpeciality, F.Title, B.Titl,  P.NumberPlaces
                            FROM Places as P, Speciality as S, FormTraning as F,BasisTraning as B
                            WHERE P.IDBasisTraning = B.ID AND F.ID = P.IDFormTraning AND P.IDSpeciality = @idd";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("idd", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[6]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                        lst[lst.Count - 1][3] = reader[3].ToString();
                        lst[lst.Count - 1][4] = reader[4].ToString();
                        lst[lst.Count - 1][5] = reader[5].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }



    }
}
/*
 * DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);

                    conn.Close();
                    //return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                //return false;
            }
     */
