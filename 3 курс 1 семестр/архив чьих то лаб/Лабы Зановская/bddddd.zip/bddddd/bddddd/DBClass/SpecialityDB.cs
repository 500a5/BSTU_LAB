﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class SpecialityDB
    {
        //список специальностей
        public List<string[]> selectAll()
        {
            List<string[]> lst2 = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {//кафедра, спец, idDep, idCagf
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT D.Title, S.Title, S.IDDepartment, S.ID FROM Department as D, Speciality as S WHERE D.ID = S.IDDepartment ORDER BY D.Title";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst2.Add(new string[4]);
                        lst2[lst2.Count - 1][0] = reader[0].ToString();
                        lst2[lst2.Count - 1][1] = reader[1].ToString();
                        lst2[lst2.Count - 1][2] = reader[2].ToString();
                        lst2[lst2.Count - 1][3] = reader[3].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst2;
        }

        //удалить специальность по title
        public bool deleteFrom(string titl)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Speciality WHERE Title = @tit";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("tit", titl);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //удалить специальность по id
        public bool deleteFrom(int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Speciality WHERE ID = @tit";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("tit", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //title по id
        public string selectOneByID(int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT Title FROM Speciality WHERE ID = @di";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("@di", id);
                    object result = cmd.ExecuteScalar();
                    result = (result == DBNull.Value) ? null : result;
                    string s = Convert.ToString(result);
                    conn.Close();
                    return s;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return "";
            }
        }

        //id по title
        public int selectOneByTITLE(string s)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = "SELECT ID FROM Speciality WHERE Title = @ti";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("@ti", s);
                    object result = cmd.ExecuteScalar();
                    conn.Close();
                    result = (result == DBNull.Value) ? null : result;
                    return Convert.ToInt32(result);
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return -1;
            }
        }

        //Добавление специальности
        public bool insertInto(string title, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO Speciality (IDDEpartment, Title) VALUES(@idd, @ti)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ti", title);
                    cmd.Parameters.AddWithValue("idd", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Обновить специальность
        public bool updateInfoTITLE(string title, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Speciality SET Title = @ti WHERE ID = @nn";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ti", title);
                    cmd.Parameters.AddWithValue("nn", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        public bool updateInfoIDDepartment(string titleSpec, int idDepart)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Speciality SET IDDepartment = @idd WHERE Title = @titt";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("titt", titleSpec);
                    cmd.Parameters.AddWithValue("idd", idDepart);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Поиск по имени
        public int search(string s)
        {//кафедра, спец, idDep, idCagf
            List<string[]> lst = this.selectAll();
            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i][1] == s)
                    return Int32.Parse(lst[i][3]);
            }
            return -1;
        }

        //Ид специальности получили, вернулии id кафедры
        public int searchIDDepartment(int idSp)
        {
            //D.Title, S.Title, S.IDDepartment, S.ID
            List<string[]> lst = this.selectAll();
            for(int i = 0; i < lst.Count; i++)
            {
                if (idSp == Int32.Parse(lst[i][3]))
                    return Int32.Parse(lst[i][2]);
            }           
            return -1;
        }
    }
}

/*
 * DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);

                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
     */
