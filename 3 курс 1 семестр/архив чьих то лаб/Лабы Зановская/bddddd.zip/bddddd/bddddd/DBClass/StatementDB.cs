﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class StatementDB
    {
        
        public List<string[]> selectByEntrant(int ide)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT S.ID, E.ID, Sp.ID, F.ID, B.ID, Sp.Title, F.Title, B.Title, S.Consent, S.OriginalDocument 
                                FROM 
                                    Statement AS S, 
                                    Speciality AS Sp, 
                                    FormTraning AS F, 
                                    BasisTraning AS B,
                                    Entrant as E
                                WHERE 
                                    S.IDBasisTraning = B.ID 
                                    AND S.IDEntrant = E.ID
                                    AND S.IDFormTraning = F.ID
                                    AND S.IDSpeciality = Sp.ID 
                                    AND S.IDEntrant = @idd";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("idd", ide);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[10]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                        lst[lst.Count - 1][3] = reader[3].ToString();
                        lst[lst.Count - 1][4] = reader[4].ToString();
                        lst[lst.Count - 1][5] = reader[5].ToString();
                        lst[lst.Count - 1][6] = reader[6].ToString();
                        lst[lst.Count - 1][7] = reader[7].ToString();
                        lst[lst.Count - 1][8] = reader[8].ToString();
                        lst[lst.Count - 1][9] = reader[9].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        public bool updateInfoSetOrigAndConsent(bool c, bool o, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Statement SET OriginalDocument = @or, Consent = @con WHERE ID = @id";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("or", o);
                    cmd.Parameters.AddWithValue("con", c);
                    cmd.Parameters.AddWithValue("id", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        public bool updateInfoSetOriginal(bool c, bool o, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Statement SET OriginalDocument = @or WHERE ID = @id";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("or", o);
                    cmd.Parameters.AddWithValue("id", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        public bool updateInfoSetConsent(bool c, bool o, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Statement SET Consent = @con WHERE ID = @id";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("con", c);
                    cmd.Parameters.AddWithValue("id", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        public bool chekPovtor(int idEntrant, int idSp, int idFt, int idBt)
        {
            List<string[]> lst = selectByEntrant(idEntrant);
            for(int i = 0; i < lst.Count; i++)
            {//S.ID, E.ID, Sp.ID, F.ID, B.ID, Sp.Title, F.Title, B.Title, S.Consent, S.OriginalDocument
                int spec = Int32.Parse(lst[i][2]);
                int form = Int32.Parse(lst[i][3]);
                int basi = Int32.Parse(lst[i][4]);
                if (idSp == spec && form == idFt && idBt == basi)
                    return true;
            }

            return false;
        }

        public bool insertInto(int idEntrant, int idSp, int idFt, int idBt, bool consen, bool orig)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO Statement 
                                (IDEntrant, IDSpeciality, IDFormTraning, IDBasisTraning, Consent, OriginalDocument)
                                VALUES (@IDE, @IDS, @IDFT, @IDBT, @CON, @OR)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("IDE", idEntrant);
                    cmd.Parameters.AddWithValue("IDS", idSp);
                    cmd.Parameters.AddWithValue("IDFT", idFt);
                    cmd.Parameters.AddWithValue("IDBT", idBt);
                    cmd.Parameters.AddWithValue("CON", consen);
                    cmd.Parameters.AddWithValue("OR", orig);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }
        
        public bool deleteFrom(int ids)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Statement WHERE ID = @id";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("id",ids);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return false;
        }

        public int countOfStateEntrant(int id)
        {
            List<string[]> lst = selectByEntrant(id);
            return lst.Count;
        }

        //Вернет истина, если такое заявление существует
        public bool checkStatement(int idE, int idS, int idF, int idB)
        {
            List<string[]> lst = selectByEntrant(idE);
            //S.ID, E.ID, Sp.ID, F.ID, B.ID, Sp.Title, F.Title, B.Title, S.Consent, S.OriginalDocument 
            for (int i = 0; i < lst.Count; i++)
            {
                int sid = Int32.Parse(lst[i][2]);
                int fid = Int32.Parse(lst[i][3]);
                int bit = Int32.Parse(lst[i][4]);
                if (sid == idS && fid == idF && bit == idB)
                    return true;
            }
            return false;
        }

        //true, если имеется одно согласие
        public bool checkConsent(int idEntrant)
        { //S.ID, E.ID, Sp.ID, F.ID, B.ID, Sp.Title, F.Title, B.Title, S.Consent, S.OriginalDocument 
            List<string[]> lst = selectByEntrant(idEntrant);
            for (int i = 0; i < lst.Count; i++)
            {
                // int con = Int32.Parse(lst[i][8]);
                bool com1 = bool.Parse(lst[i][8]);
                //if (con == 1)
                if(com1)
                    return true;
            }
            return false;
        }

        //true, если имеется оригинал
        public bool checkOriginalDoc(int idEntrant)
        {
            List<string[]> lst = selectByEntrant(idEntrant);
            for (int i = 0; i < lst.Count; i++)
            {
                // int con = Int32.Parse(lst[i][9]);
                bool com1 = bool.Parse(lst[i][9]);
                if (com1)
                    return true;
            }
            return false;
        }

        public List<string> oneStatement(int idStat, int idEntrant)
        {
            List<string> s = new List<string>();
            List<string[]> lst = selectByEntrant(idEntrant);
            for (int i = 0; i<lst.Count; i++)
            {
                //S.ID, E.ID, Sp.ID, F.ID, B.ID, Sp.Title, F.Title, B.Title, S.Consent, S.OriginalDocument 
                if (idStat == Int32.Parse(lst[i][0]))
                {
                    for(int j=0; j<10; j++)
                    {
                        s.Add(lst[i][j]);
                        // s[j] =;
                    }
                    return s;
                }

            }
            return s;
        }

    }
}
