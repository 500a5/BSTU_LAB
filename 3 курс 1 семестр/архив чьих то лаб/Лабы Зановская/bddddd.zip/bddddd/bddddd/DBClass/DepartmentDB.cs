﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class DepartmentDB
    {
        //Получить список кафедр
        public List<string[]> selectAll()
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT D.Title, D.ID FROM Department as D";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[2]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //Удалить кафедру по title
        public bool deleteFrom(string titl)
        {          
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Department WHERE Title = @tit";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("tit", titl);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return false;
        }

        //Удалить кафедру по id
        public bool deleteFrom(int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM Department WHERE ID = @tit";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("tit", id);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return false;
        }

        //Название по ID
        public string selectOneByID(int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT Title FROM Department WHERE ID = @di";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("@di", id);
                    object result = cmd.ExecuteScalar();
                    conn.Close();
                    result = (result == DBNull.Value) ? null : result;
                    string s = Convert.ToString(result);                                      
                    return s;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return "";
            }
        }

        //ID по названию
        public int selectOneByTITLE(string s)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = "SELECT ID FROM Department WHERE Title = @ti";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("@ti", s);
                    object result = cmd.ExecuteScalar();
                    conn.Close();
                    result = (result == DBNull.Value) ? null : result;
                    return Convert.ToInt32(result);
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return -1;
            }
        }

        //Добавить название одной кафедры
        public bool insertInto(string title)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO Department (Title) VALUES(@ti)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ti", title);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;                   
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Обновить название кафедры
        public bool updateInfo(string title, int id)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE Department SET Title = @ti WHERE ID = @nn";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ti", title);
                    cmd.Parameters.AddWithValue("nn", id);
                    cmd.ExecuteNonQuery();                    
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Возвращает id кафедры, если кафедра с title s существует
        public int search(string s)
        {
            List<string[]> lst = this.selectAll();
            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i][0] == s)
                    return Int32.Parse(lst[i][1]);
            }
            return -1;
        }
    }
}
