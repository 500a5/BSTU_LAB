﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace bddddd.DBClass
{
    class MinScoreDB
    {
        //мин баллы по специальностям
        public List<string[]> selectAll()
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT S.Title, D.Title, M.Point, D.ID, S.ID 
                                   FROM Speciality as S, MinimumScore as M, Discipline as D 
                                   WHERE S.ID = M.IDSpeciality and M.IDDiscipline = D.ID";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[5]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                        lst[lst.Count - 1][3] = reader[3].ToString();
                        lst[lst.Count - 1][4] = reader[4].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //мин баллы по специальностям
        public List<string[]> selectBySpec(int idSpec)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT D.ID, D.Title, M.Point,
                                   FROM Speciality as S, MinimumScore as M, Discipline as D 
                                   WHERE S.ID = M.IDSpeciality and M.IDDiscipline = D.ID AND S.ID = @ids";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ids", idSpec);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[3]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        //Добавление минимальных баллов
        public bool insertInto(int poi, int idD, int idS)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"INSERT INTO MinimumScore (IDDiscipline, IDSpeciality, Point) VALUES(@idd, @ids, @po)";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("po", poi);
                    cmd.Parameters.AddWithValue("idd", idD);
                    cmd.Parameters.AddWithValue("ids", idS);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Минимальные баллы для специальности с индексом id
        public List<string[]> selectByID(int id)
        {
            List<string[]> lst = new List<string[]>();
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"SELECT D.ID, S.ID, S.Title, D.Title, M.Point FROM Speciality as S, MinimumScore as M, Discipline as D WHERE S.ID = M.IDSpeciality and M.IDDiscipline = D.ID AND S.ID = @idd";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("idd", id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        lst.Add(new string[5]);
                        lst[lst.Count - 1][0] = reader[0].ToString();
                        lst[lst.Count - 1][1] = reader[1].ToString();
                        lst[lst.Count - 1][2] = reader[2].ToString();
                        lst[lst.Count - 1][3] = reader[3].ToString();
                        lst[lst.Count - 1][4] = reader[4].ToString();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
            return lst;
        }

        public bool updateInfo(int poi, int s, int d)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"UPDATE MinimumScore SET Point = @ti WHERE IDDiscipline = @idd AND IDSpeciality = @ids";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("ti", poi);
                    cmd.Parameters.AddWithValue("idd", d);
                    cmd.Parameters.AddWithValue("ids", s);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //delete минимальные баллы
        public bool deleteFrom(int s, int d)
        {
            DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);
                    string str = @"DELETE FROM MinimumScore WHERE IDDiscipline = @idd AND IDSpeciality = @ids";
                    SqlCommand cmd = new SqlCommand(str, conn);
                    cmd.Parameters.AddWithValue("idd", d);
                    cmd.Parameters.AddWithValue("ids", s);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
                return false;
            }
        }

        //Вернет id дисциплины, если такая есть
        public int searchIDD(string spec)
        {
            //S.Title, D.Title, M.Point, D.ID, S.ID 
            List<string[]> lst2 = this.selectAll();
            for (int i = 0; i < lst2.Count; i++)
            {
                if (lst2[i][0] == spec)
                    return Int32.Parse(lst2[i][3]);
            }
            return -1;
        }

        public int countStringsOfSpec(string spec)
        {
            int count = 0;
            //S.Title, D.Title, M.Point, D.ID, S.ID 
            List<string[]> lst = this.selectAll();
            for (int i = 0; i < lst.Count; i++)
            {
                if (spec == lst[i][0])
                    count++;
            }
            return count;
        }

        //Вернет id спец, если такая есть
        public int searchIDS(string spec)
        {
            //S.Title, D.Title, M.Point, D.ID, S.ID 
            List<string[]> lst2 = this.selectAll();
            for (int i = 0; i < lst2.Count; i++)
            {
                if (lst2[i][0] == spec)
                    return Int32.Parse(lst2[i][4]);
            }
            return -1;
        }
    }
}
/*
 * DBConn dbc = new DBConn();
            try
            {
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                using (SqlConnection conn = new SqlConnection())
                {
                    dbc.OpenConn(sb, conn);

                    conn.Close();
                }
            }
            catch (System.Data.SqlClient.SqlException)
            {
                MessageBox.Show("Ошибка соединения", "Ошибка!");
            }
     */
