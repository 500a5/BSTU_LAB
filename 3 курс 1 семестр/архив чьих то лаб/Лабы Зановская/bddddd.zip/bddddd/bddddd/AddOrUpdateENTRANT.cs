﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bddddd.DBClass;

namespace bddddd.DBClass
{
    public partial class AddOrUpdateENTRANT : Form
    {
        EntrantDB entrant = new EntrantDB();
        int idAbit = -1;

        public AddOrUpdateENTRANT()
        {
            InitializeComponent();
        }

        public AddOrUpdateENTRANT(int i)
        {
            InitializeComponent();
            this.idAbit = i;
        }

        private void AddOrUpdateENTRANT_Load(object sender, EventArgs e)
        {
            if (idAbit != -1)
                setToUpdate();
        }

        private void otmenaButtom_Click(object sender, EventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
            this.Close();
        }

        private void AddOrUpdateENTRANT_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
        }

        private void saveButt_Click(object sender, EventArgs e)
        {
            bool flag;
            if (idAbit == -1)
                flag = addInformation();
            else
                flag = updateInformation();
            if (flag)
            {
                MessageBox.Show("Изменения выполнены", "Успешно!");
                Form ifrm = Application.OpenForms[0];
                ifrm.Show();
                this.Close();
            }

        }

        //update
        private bool updateInformation()
        {
            errorSurname.Clear();
            errorName.Clear();
            errorPasp.Clear();
            errorPred.Clear();
            errorCont.Clear();
            errorAdres.Clear();
            bool flag = checkInfo();
            bool endFlag = false;
            if (flag)//если все заполнено
            {
                string sr, nm, pat, pasp, adr, con, pred;
                sr = textBox_Surname.Text;
                nm = textBox_Name.Text;
                pat = textBox_Patron.Text;
                pasp = textBox_Passp1.Text;
                adr = textBox_Adr.Text;
                con = textBox_Cont1.Text;
                pred = textBox__pred.Text;
                DateTimePicker dt = birth;

                if (pat == "")
                {
                   endFlag = entrant.updateIfoNOPATRON(sr, nm, pasp, adr, dt, con, pred, checkBox_HOSTEL.Checked, idAbit);
                   return endFlag;
                }
                else
                {
                    endFlag = entrant.updateIfoPATRON(sr, nm, pat, pasp, adr, dt, con, pred, checkBox_HOSTEL.Checked, idAbit);
                    return endFlag;
                }                        
            }
            return endFlag;
        }

        //добавление
        private bool addInformation()
        {
            errorSurname.Clear();
            errorName.Clear();
            errorPasp.Clear();
            errorPred.Clear();
            errorCont.Clear();
            errorAdres.Clear();
            bool flag = checkInfo();
            if (flag)//если все заполнено
            {
                string sr, nm, pat, pasp, adr, con, pred;
                sr = textBox_Surname.Text;
                nm = textBox_Name.Text;
                pat = textBox_Patron.Text;
                pasp = textBox_Passp1.Text;
                adr = textBox_Adr.Text;
                con = textBox_Cont1.Text;
                pred = textBox__pred.Text;
                DateTimePicker dt = birth;
                int endFlag;

                if(pat == "")
                {
                    endFlag = entrant.insertIntoNoPatron(sr, nm, pasp, adr, dt, con, pred, checkBox_HOSTEL.Checked);
                }
                else
                {
                    endFlag = entrant.insertIntoPatron(sr, nm, pat, pasp, adr, dt, con, pred, checkBox_HOSTEL.Checked);
                }
                
                if (endFlag > 0)
                {
                //    MessageBox.Show("Выполнено добавление записи", "Успешно!");
                    return true;
                }
                else
                {
                  //  MessageBox.Show("Добавление не выполнено", "Ошибка!");
                }
            }
            return false;
        }

        //Проверка заполнения
        private bool checkInfo()
        {
            bool flag = true;
            if (textBox_Surname.Text == "")
            {
                errorSurname.SetError(textBox_Surname, "Не указана фамилия!");
                flag = false;
            }

            if (textBox_Name.Text == "")
            {
                errorName.SetError(textBox_Name, "Не указано имя!");
                flag = false;
            }

            //if (textBox_Passp.Text == "")
            if (textBox_Passp1.Text == "")
            {
                errorPasp.SetError(textBox_Passp1, "Не указан паспорт!");
                flag = false;
            }

            if (textBox_Adr.Text == "")
            {
                errorAdres.SetError(textBox_Adr, "Не указан адрес!");
                flag = false;
            }

            if (textBox_Cont1.Text == "")
            {
                errorCont.SetError(textBox_Cont1, "Не указаны конт. данные!");
                flag = false;
            }

            if (textBox__pred.Text == "")
            {
                errorPred.SetError(textBox__pred, "Не указано пред. образование!");
                flag = false;
            }

            return flag;
        }

        private void setToUpdate()
        {
            //idAbit код абика
            List<string[]> lst = entrant.selectOne(idAbit); //получили информацию об одном абике 
            //ид фамилия имя отчество паспорт адрес дата рождения контакт образование общага
            textBox_Surname.Text = lst[0][1];
            textBox_Name.Text = lst[0][2];
            textBox_Patron.Text = lst[0][3];
            textBox_Passp1.Text = lst[0][4];
            textBox_Adr.Text = lst[0][5];
            textBox_Cont1.Text = lst[0][7];
            textBox__pred.Text = lst[0][8];
            checkBox_HOSTEL.Checked = (lst[0][9].ToString() == "True");
            birth.Value = Convert.ToDateTime(lst[0][6]);
        }

    }
}
