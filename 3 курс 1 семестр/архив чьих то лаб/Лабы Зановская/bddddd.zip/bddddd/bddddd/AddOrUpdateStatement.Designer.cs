﻿namespace bddddd
{
    partial class AddOrUpdateStatement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BOXconsent = new System.Windows.Forms.CheckBox();
            this.BOXoriginal = new System.Windows.Forms.CheckBox();
            this.surTEXT = new System.Windows.Forms.TextBox();
            this.patrTEXT = new System.Windows.Forms.TextBox();
            this.nameTEXT = new System.Windows.Forms.TextBox();
            this.otmenaBUTTON = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.saveBUTTON = new System.Windows.Forms.Button();
            this.erSP = new System.Windows.Forms.ErrorProvider(this.components);
            this.erFT = new System.Windows.Forms.ErrorProvider(this.components);
            this.erBT = new System.Windows.Forms.ErrorProvider(this.components);
            this.origHelp = new System.Windows.Forms.HelpProvider();
            this.consentHelp = new System.Windows.Forms.HelpProvider();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erSP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erFT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erBT)).BeginInit();
            this.SuspendLayout();
            // 
            // BOXconsent
            // 
            this.BOXconsent.AutoSize = true;
            this.BOXconsent.Location = new System.Drawing.Point(178, 100);
            this.BOXconsent.Name = "BOXconsent";
            this.BOXconsent.Size = new System.Drawing.Size(74, 17);
            this.BOXconsent.TabIndex = 0;
            this.BOXconsent.Text = "Согласие";
            this.BOXconsent.UseVisualStyleBackColor = true;
            // 
            // BOXoriginal
            // 
            this.BOXoriginal.AutoSize = true;
            this.BOXoriginal.Location = new System.Drawing.Point(6, 100);
            this.BOXoriginal.Name = "BOXoriginal";
            this.BOXoriginal.Size = new System.Drawing.Size(75, 17);
            this.BOXoriginal.TabIndex = 1;
            this.BOXoriginal.Text = "Оригинал";
            this.BOXoriginal.UseVisualStyleBackColor = true;
            // 
            // surTEXT
            // 
            this.surTEXT.Location = new System.Drawing.Point(13, 13);
            this.surTEXT.Name = "surTEXT";
            this.surTEXT.Size = new System.Drawing.Size(259, 20);
            this.surTEXT.TabIndex = 2;
            // 
            // patrTEXT
            // 
            this.patrTEXT.Location = new System.Drawing.Point(13, 65);
            this.patrTEXT.Name = "patrTEXT";
            this.patrTEXT.Size = new System.Drawing.Size(259, 20);
            this.patrTEXT.TabIndex = 3;
            // 
            // nameTEXT
            // 
            this.nameTEXT.Location = new System.Drawing.Point(13, 39);
            this.nameTEXT.Name = "nameTEXT";
            this.nameTEXT.Size = new System.Drawing.Size(259, 20);
            this.nameTEXT.TabIndex = 4;
            // 
            // otmenaBUTTON
            // 
            this.otmenaBUTTON.Location = new System.Drawing.Point(196, 225);
            this.otmenaBUTTON.Name = "otmenaBUTTON";
            this.otmenaBUTTON.Size = new System.Drawing.Size(75, 23);
            this.otmenaBUTTON.TabIndex = 5;
            this.otmenaBUTTON.Text = "Отмена";
            this.otmenaBUTTON.UseVisualStyleBackColor = true;
            this.otmenaBUTTON.Click += new System.EventHandler(this.otmenaBUTTON_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(103, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(129, 21);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.SelectedValueChanged += new System.EventHandler(this.comboBox1_SelectedValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.BOXconsent);
            this.groupBox1.Controls.Add(this.BOXoriginal);
            this.groupBox1.Location = new System.Drawing.Point(13, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(258, 127);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Основа";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Форма";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Специальность";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(103, 73);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(129, 21);
            this.comboBox3.TabIndex = 8;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(103, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(129, 21);
            this.comboBox2.TabIndex = 7;
            this.comboBox2.SelectedValueChanged += new System.EventHandler(this.comboBox2_SelectedValueChanged);
            // 
            // saveBUTTON
            // 
            this.saveBUTTON.Location = new System.Drawing.Point(13, 225);
            this.saveBUTTON.Name = "saveBUTTON";
            this.saveBUTTON.Size = new System.Drawing.Size(75, 23);
            this.saveBUTTON.TabIndex = 8;
            this.saveBUTTON.Text = "Сохранить";
            this.saveBUTTON.UseVisualStyleBackColor = true;
            this.saveBUTTON.Click += new System.EventHandler(this.saveBUTTON_Click);
            // 
            // erSP
            // 
            this.erSP.ContainerControl = this;
            // 
            // erFT
            // 
            this.erFT.ContainerControl = this;
            // 
            // erBT
            // 
            this.erBT.ContainerControl = this;
            // 
            // AddOrUpdateStatement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 255);
            this.Controls.Add(this.saveBUTTON);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.otmenaBUTTON);
            this.Controls.Add(this.nameTEXT);
            this.Controls.Add(this.patrTEXT);
            this.Controls.Add(this.surTEXT);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "AddOrUpdateStatement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddOrUpdateStatement";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddOrUpdateStatement_FormClosed);
            this.Load += new System.EventHandler(this.AddOrUpdateStatement_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erSP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erFT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erBT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox BOXconsent;
        private System.Windows.Forms.CheckBox BOXoriginal;
        private System.Windows.Forms.TextBox surTEXT;
        private System.Windows.Forms.TextBox patrTEXT;
        private System.Windows.Forms.TextBox nameTEXT;
        private System.Windows.Forms.Button otmenaBUTTON;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button saveBUTTON;
        private System.Windows.Forms.ErrorProvider erSP;
        private System.Windows.Forms.ErrorProvider erFT;
        private System.Windows.Forms.ErrorProvider erBT;
        private System.Windows.Forms.HelpProvider origHelp;
        private System.Windows.Forms.HelpProvider consentHelp;
    }
}