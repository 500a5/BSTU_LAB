﻿namespace bddddd
{
    partial class AddOrUpdateMINSCORE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox_BALLS = new System.Windows.Forms.TextBox();
            this.comboBox_DICS = new System.Windows.Forms.ComboBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox_SPEC = new System.Windows.Forms.TextBox();
            this.errorProv = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProv)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_BALLS
            // 
            this.textBox_BALLS.Location = new System.Drawing.Point(8, 86);
            this.textBox_BALLS.Name = "textBox_BALLS";
            this.textBox_BALLS.Size = new System.Drawing.Size(242, 20);
            this.textBox_BALLS.TabIndex = 0;
            // 
            // comboBox_DICS
            // 
            this.comboBox_DICS.FormattingEnabled = true;
            this.comboBox_DICS.Location = new System.Drawing.Point(8, 48);
            this.comboBox_DICS.Name = "comboBox_DICS";
            this.comboBox_DICS.Size = new System.Drawing.Size(242, 21);
            this.comboBox_DICS.TabIndex = 1;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(8, 113);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Сохранить";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(175, 113);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Отмена";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox_SPEC
            // 
            this.textBox_SPEC.Location = new System.Drawing.Point(8, 13);
            this.textBox_SPEC.Name = "textBox_SPEC";
            this.textBox_SPEC.ReadOnly = true;
            this.textBox_SPEC.Size = new System.Drawing.Size(242, 20);
            this.textBox_SPEC.TabIndex = 4;
            // 
            // errorProv
            // 
            this.errorProv.ContainerControl = this;
            // 
            // AddOrUpdateMINSCORE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 143);
            this.Controls.Add(this.textBox_SPEC);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.comboBox_DICS);
            this.Controls.Add(this.textBox_BALLS);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "AddOrUpdateMINSCORE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddOrUpdateMINSCORE";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddOrUpdateMINSCORE_FormClosed);
            this.Load += new System.EventHandler(this.AddOrUpdateMINSCORE_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_BALLS;
        private System.Windows.Forms.ComboBox comboBox_DICS;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox_SPEC;
        private System.Windows.Forms.ErrorProvider errorProv;
    }
}