﻿namespace bddddd.DBClass
{
    partial class AddOrUpdateENTRANT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox_Surname = new System.Windows.Forms.TextBox();
            this.textBox_Patron = new System.Windows.Forms.TextBox();
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.textBox_Adr = new System.Windows.Forms.TextBox();
            this.birth = new System.Windows.Forms.DateTimePicker();
            this.textBox__pred = new System.Windows.Forms.TextBox();
            this.checkBox_HOSTEL = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.saveButt = new System.Windows.Forms.Button();
            this.otmenaButtom = new System.Windows.Forms.Button();
            this.errorSurname = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorPasp = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorAdres = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorCont = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorPred = new System.Windows.Forms.ErrorProvider(this.components);
            this.textBox_Passp1 = new System.Windows.Forms.MaskedTextBox();
            this.textBox_Cont1 = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorSurname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPasp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorAdres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorCont)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPred)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_Surname
            // 
            this.textBox_Surname.Location = new System.Drawing.Point(156, 10);
            this.textBox_Surname.Name = "textBox_Surname";
            this.textBox_Surname.Size = new System.Drawing.Size(170, 20);
            this.textBox_Surname.TabIndex = 0;
            // 
            // textBox_Patron
            // 
            this.textBox_Patron.Location = new System.Drawing.Point(156, 62);
            this.textBox_Patron.Name = "textBox_Patron";
            this.textBox_Patron.Size = new System.Drawing.Size(170, 20);
            this.textBox_Patron.TabIndex = 1;
            // 
            // textBox_Name
            // 
            this.textBox_Name.Location = new System.Drawing.Point(156, 36);
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.Size = new System.Drawing.Size(170, 20);
            this.textBox_Name.TabIndex = 2;
            // 
            // textBox_Adr
            // 
            this.textBox_Adr.Location = new System.Drawing.Point(156, 114);
            this.textBox_Adr.Name = "textBox_Adr";
            this.textBox_Adr.Size = new System.Drawing.Size(170, 20);
            this.textBox_Adr.TabIndex = 4;
            // 
            // birth
            // 
            this.birth.Location = new System.Drawing.Point(156, 141);
            this.birth.Name = "birth";
            this.birth.Size = new System.Drawing.Size(170, 20);
            this.birth.TabIndex = 5;
            // 
            // textBox__pred
            // 
            this.textBox__pred.Location = new System.Drawing.Point(156, 193);
            this.textBox__pred.Name = "textBox__pred";
            this.textBox__pred.Size = new System.Drawing.Size(170, 20);
            this.textBox__pred.TabIndex = 7;
            // 
            // checkBox_HOSTEL
            // 
            this.checkBox_HOSTEL.AutoSize = true;
            this.checkBox_HOSTEL.Location = new System.Drawing.Point(15, 228);
            this.checkBox_HOSTEL.Name = "checkBox_HOSTEL";
            this.checkBox_HOSTEL.Size = new System.Drawing.Size(167, 17);
            this.checkBox_HOSTEL.TabIndex = 8;
            this.checkBox_HOSTEL.Text = "Необходимость общежития";
            this.checkBox_HOSTEL.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Фамилия";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Имя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Отчество";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Паспорт";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Адрес";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Дата рождения";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Контактные данные";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 196);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Предыдущее образование";
            // 
            // saveButt
            // 
            this.saveButt.Location = new System.Drawing.Point(15, 252);
            this.saveButt.Name = "saveButt";
            this.saveButt.Size = new System.Drawing.Size(75, 23);
            this.saveButt.TabIndex = 17;
            this.saveButt.Text = "Сохранить";
            this.saveButt.UseVisualStyleBackColor = true;
            this.saveButt.Click += new System.EventHandler(this.saveButt_Click);
            // 
            // otmenaButtom
            // 
            this.otmenaButtom.Location = new System.Drawing.Point(251, 252);
            this.otmenaButtom.Name = "otmenaButtom";
            this.otmenaButtom.Size = new System.Drawing.Size(75, 23);
            this.otmenaButtom.TabIndex = 18;
            this.otmenaButtom.Text = "Отмена";
            this.otmenaButtom.UseVisualStyleBackColor = true;
            this.otmenaButtom.Click += new System.EventHandler(this.otmenaButtom_Click);
            // 
            // errorSurname
            // 
            this.errorSurname.ContainerControl = this;
            // 
            // errorName
            // 
            this.errorName.ContainerControl = this;
            // 
            // errorPasp
            // 
            this.errorPasp.ContainerControl = this;
            // 
            // errorAdres
            // 
            this.errorAdres.ContainerControl = this;
            // 
            // errorCont
            // 
            this.errorCont.ContainerControl = this;
            // 
            // errorPred
            // 
            this.errorPred.ContainerControl = this;
            // 
            // textBox_Passp1
            // 
            this.textBox_Passp1.Location = new System.Drawing.Point(156, 88);
            this.textBox_Passp1.Mask = "9999 999999";
            this.textBox_Passp1.Name = "textBox_Passp1";
            this.textBox_Passp1.Size = new System.Drawing.Size(170, 20);
            this.textBox_Passp1.TabIndex = 19;
            // 
            // textBox_Cont1
            // 
            this.textBox_Cont1.Location = new System.Drawing.Point(156, 167);
            this.textBox_Cont1.Mask = "0(999) 000-0000";
            this.textBox_Cont1.Name = "textBox_Cont1";
            this.textBox_Cont1.Size = new System.Drawing.Size(170, 20);
            this.textBox_Cont1.TabIndex = 20;
            // 
            // AddOrUpdateENTRANT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 287);
            this.Controls.Add(this.textBox_Cont1);
            this.Controls.Add(this.textBox_Passp1);
            this.Controls.Add(this.otmenaButtom);
            this.Controls.Add(this.saveButt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox_HOSTEL);
            this.Controls.Add(this.textBox__pred);
            this.Controls.Add(this.birth);
            this.Controls.Add(this.textBox_Adr);
            this.Controls.Add(this.textBox_Name);
            this.Controls.Add(this.textBox_Patron);
            this.Controls.Add(this.textBox_Surname);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "AddOrUpdateENTRANT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddOrUpdateENTRANT";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddOrUpdateENTRANT_FormClosed);
            this.Load += new System.EventHandler(this.AddOrUpdateENTRANT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorSurname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPasp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorAdres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorCont)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPred)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Surname;
        private System.Windows.Forms.TextBox textBox_Patron;
        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.TextBox textBox_Adr;
        private System.Windows.Forms.DateTimePicker birth;
        private System.Windows.Forms.TextBox textBox__pred;
        private System.Windows.Forms.CheckBox checkBox_HOSTEL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button saveButt;
        private System.Windows.Forms.Button otmenaButtom;
        private System.Windows.Forms.ErrorProvider errorSurname;
        private System.Windows.Forms.ErrorProvider errorName;
        private System.Windows.Forms.ErrorProvider errorPasp;
        private System.Windows.Forms.ErrorProvider errorAdres;
        private System.Windows.Forms.ErrorProvider errorCont;
        private System.Windows.Forms.ErrorProvider errorPred;
        private System.Windows.Forms.MaskedTextBox textBox_Passp1;
        private System.Windows.Forms.MaskedTextBox textBox_Cont1;
    }
}