﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bddddd.DBClass;

namespace bddddd
{
    public partial class AddOrUpdateEntrantPoint : Form
    {
        EntrantDB entran = new EntrantDB();
        PointDB pointDB = new PointDB();
        DisciplineDB discipline = new DisciplineDB();
        //MinScoreDB minscore = new MinScoreDB();

        int idEntr = 1;
        int idDs = -1;
        bool addFlag = false; //если тру, то добавляем

        public AddOrUpdateEntrantPoint(int id, bool flag)
        {
            InitializeComponent();
            this.idEntr = id;
            this.addFlag = flag;             
        }

        //изменение
        public AddOrUpdateEntrantPoint(int id, bool flag, int idDisc)
        {
            InitializeComponent();
            this.idEntr = id;
            this.addFlag = flag;
            this.idDs = idDisc;
        }
        
        private void AddOrUpdateEntrantPoint_Load(object sender, EventArgs e)
        {
            showFIOEntrant();
            if (addFlag)
            {
                showDiscipline();
            }
            else
            {
                string title = discipline.searchTitle(idDs); //нашли тайтл дисциплины
                comboBox1.Items.Add(title);
                comboBox1.SelectedIndex = comboBox1.FindStringExact(title);
                comboBox1.Enabled = false;
                showPoint();
            }
                
        }

        private void showFIOEntrant()
        {
            List<string[]> lst = entran.selectOne(idEntr);
            textBox1.Text = lst[0][1];
            textBox2.Text = lst[0][2];
            textBox3.Text = lst[0][3];
        }

        private void showDiscipline()
        {
            List<string[]> lstDisc = discipline.selectAll(); //все дисциплины
            for(int i = 0; i< lstDisc.Count; i++)
            {
                int j = Int32.Parse(lstDisc[i][1]);
                if (pointDB.searchhPointInEntrant(idEntr, j) == -1)
                    comboBox1.Items.Add(lstDisc[i][0]);
            }
        }

        private void showPoint()
        {
            int point = pointDB.searchhPointInEntrant(idEntr, idDs);
            textBox4.Text = point.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
            this.Close();
        }

        private void AddOrUpdateEntrantPoint_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //В любом случае проверяем баллы
            if (addFlag)
            {
                addInformation();
            }
            else
            {
                updateInformation();
            }
        }

        private void updateInformation()
        {
            bool fl = checkBoxes();
            if (fl)
            {
                int poi = Int32.Parse(textBox4.Text);
                if(pointDB.updateInfo(idDs, idEntr, poi))
                {
                    MessageBox.Show("Изменение выполнено!", "Успешно!");
                    Form ifrm = Application.OpenForms[0];
                    ifrm.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Изменение не выполнено!", "Ошибка!");
                }
            }
        }

        private void addInformation()
        {
            bool fl = checkBoxes();
            if (fl)
            {
                int poi = Int32.Parse(textBox4.Text);
                int idd = discipline.searchId(comboBox1.Text);
                if (pointDB.insertInto(idd, idEntr, poi))
                {
                    MessageBox.Show("Добавление выполнено!", "Успешно!");
                    Form ifrm = Application.OpenForms[0];
                    ifrm.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Добавление не выполнено!", "Ошибка!");
                }
            }
        }

        private bool checkBoxes()
        {
            errorPO.Clear();
            errorDS.Clear();
            bool flag = true;
            int j;
            if (comboBox1.Text == "")
            {
                flag = false;
                errorDS.SetError(comboBox1, "Не указана дисциплина!");
            }
                
            if(textBox4.Text == "")
            {                
                errorPO.SetError(textBox4, "Не указаны баллы!");
                return false;
            }
            else if(!Int32.TryParse(textBox4.Text, out j))
            {
                errorPO.SetError(textBox4, "Баллы должны быть числом!");
                return false;
            }
            else if(j < 0)
            {
                errorPO.SetError(textBox4, "Баллы не могут быть отрицательными!");
                return false;
            }
            else if (j > 100)
            {
                errorPO.SetError(textBox4, "Балл не может превышать 100!");
                return false;
            }
            else if(j <= 19)
            {
                errorPO.SetError(textBox4, "Не принимаются предметы с баллом, ниже 20!");
                return false;
            }
            return flag;
        }
    }
}
