﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bddddd.DBClass;

namespace bddddd
{
    public partial class AddOrUpdateStatement : Form
    {
        EntrantDB entran = new EntrantDB();
        StatementDB statement = new StatementDB();
        FormBasisTraningDB formBasis = new FormBasisTraningDB();
        SpecialityDB speciality = new SpecialityDB();
        MinScoreDB minScore = new MinScoreDB();
        PointDB point = new PointDB();
        PlacesDB placeS = new PlacesDB();


        int idEntrant = -1;
        int idStatement = -1;
        bool con = false; //если true, то у него есть одно согласие
        bool OD = false;

        bool addorup = false; //add +, up - 

        //доб
        public AddOrUpdateStatement(int addEntr, bool addCon, bool addOD, bool add)
        {
            InitializeComponent();
            this.idEntrant = addEntr;
            this.con = addCon;
            this.OD = addOD;
            this.addorup = add;
        }

        //изменение
        public AddOrUpdateStatement(int upEntr, int upStat, bool up)
        {
            InitializeComponent();
            this.idEntrant = upEntr;
            this.addorup = up;
            this.idStatement = upStat;
        }

        private void AddOrUpdateStatement_Load(object sender, EventArgs e)
        {
            if (addorup)
            {
                showToAdd();
                showSpec();
            }
            if(!addorup)
            {
                showToUp();
            }
        }

        private void showSpec()
        {
            List<string[]> spec = speciality.selectAll();               //все специальности D.Title, S.Title, S.IDDepartment, S.ID
            //List<string[]> entrPoint = point.selectByEntrant(idEntrant);//баллы абитуриента
            bool flag = false;

            for (int i = 0; i <spec.Count; i++)
            {
                flag = false;
                int ids = Int32.Parse(spec[i][3]); //ид дисциплины в специальности 
                flag = canSentStatement(idEntrant, ids);
                if (flag)
                    comboBox1.Items.Add(spec[i][1]);
            }
            
        }

        private void showToUp()
        {

            //S.ID, E.ID, Sp.ID, F.ID, B.ID, Sp.Title, F.Title, B.Title, S.Consent, S.OriginalDocument 
            List<string> s = statement.oneStatement(idStatement, idEntrant);//информация о заявлении по коду и по абитуриента

            comboBox1.Items.Clear();
            comboBox1.Items.Add(s[5]);
            comboBox1.SelectedIndex = comboBox1.FindStringExact(s[5]);

            comboBox2.Items.Clear();
            comboBox2.Items.Add(s[6]);
            comboBox2.SelectedIndex = comboBox2.FindStringExact(s[6]);

            comboBox3.Items.Clear();
            comboBox3.Items.Add(s[7]);
            comboBox3.SelectedIndex = comboBox3.FindStringExact(s[7]);


            BOXconsent.Checked = (s[8] == "True") ? true : false;       //независимо от булов выше заполняем
            BOXoriginal.Checked = (s[9] == "True") ? true : false;      //==1==1==1==1==1==1

            //Записываем информацию в чек бкос
            bool haveOneConsent = statement.checkConsent(idEntrant);        //Если у абитуриента существует согласие
            bool haveOneOrigDoc = statement.checkOriginalDoc(idEntrant);    //Если у абитуриента существует оригинал


            if (haveOneConsent && BOXconsent.Checked)//если сщуествует согласие, и оно на эту специальность, его можно убрать
            {
                BOXconsent.Enabled = true;
            }
            else if(haveOneConsent && !BOXconsent.Checked)
            {
                BOXconsent.Enabled = false;
            }
            else if (!haveOneConsent)
            {
                BOXconsent.Enabled = true;
            }


            if (haveOneOrigDoc && BOXoriginal.Checked)//если сщуествует согласие, и оно на эту специальность, его можно убрать
            {
                BOXoriginal.Enabled = true;
            }
            else if (haveOneOrigDoc && !BOXoriginal.Checked)
            {
                BOXoriginal.Enabled = false;
            }
            else if (!haveOneOrigDoc)
            {
                BOXoriginal.Enabled = true;
            }

            List<string[]> lst = entran.selectOne(idEntrant);
            surTEXT.Text = lst[0][1];
            nameTEXT.Text = lst[0][2];
            patrTEXT.Text = lst[0][3];

            surTEXT.Enabled = false;
            nameTEXT.Enabled = false;
            patrTEXT.Enabled = false;
        }

        private bool canSentStatement(int idEntr, int idSpec)
        {
            //D.ID, S.ID, S.Title, D.Title, M.Point
            List<string[]> ms = minScore.selectByID(idSpec);

            //E.ID, D.ID, D.Title, P.Point 
            List<string[]> poineEnt = point.selectByEntrant(idEntr);
            byte predm=0;
            for (int i=0; i<ms.Count;i++)
            {
                for (int j=0; j<poineEnt.Count;j++)
                {
                    int idMs = Int32.Parse(ms[i][0]); //for debug
                    int idEntrant = Int32.Parse(poineEnt[j][1]); 
                    if (idMs == idEntrant)
                    {
                        if (Int32.Parse(poineEnt[j][3])>= Int32.Parse(ms[i][4]))
                            predm++;
                    }
                }
            }
            if (predm >= ms.Count)
                return true;
            return false;
        }

        private void showToAdd()
        {
            if (con)
            {
                BOXconsent.Enabled = false;
            }

                
            if (OD)
            {
                BOXoriginal.Enabled = false;
            }

                
            List<string[]> lst = entran.selectOne(idEntrant);
            surTEXT.Text = lst[0][1];
            nameTEXT.Text = lst[0][2];
            patrTEXT.Text = lst[0][3];

            surTEXT.Enabled = false;
            nameTEXT.Enabled = false;
            patrTEXT.Enabled = false;
        }

        private void otmenaBUTTON_Click(object sender, EventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
            this.Close();
        }

        private void AddOrUpdateStatement_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
        }

        private void updateInfo()
        {
            if (checkForm())
            {
                bool sogl = false, ori = false;
                if (con == false)
                    sogl = BOXconsent.Checked;                
                if (OD == false)
                    ori = BOXoriginal.Checked;
                if(statement.updateInfoSetOrigAndConsent(sogl, ori, idStatement))
                {
                    MessageBox.Show("Изменение записи выполнено!", "Успешно");
                    Form ifrm = Application.OpenForms[0];
                    ifrm.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Изменение записи не выполнено!", "Ошибка");
                }
            }
        }

        private void addInfo()
        {
            if (checkForm())
            {
                bool sogl = false, ori = false;
                /* if (!con)                    sogl = true;
                 if (!OD)                    ori = true;*/
                if (con == false)
                {
                    sogl = BOXconsent.Checked;
                }

                if (OD == false)
                {
                    ori = BOXoriginal.Checked;
                }

                int idSpe = speciality.search(comboBox1.Text);
                int idFt = formBasis.searchForm(comboBox2.Text);
                int idBt = formBasis.searchBasis(comboBox3.Text);
                if(!statement.chekPovtor(idEntrant, idSpe, idFt, idBt))
                {
                    if (statement.insertInto(idEntrant, idSpe, idFt, idBt, sogl, ori))
                    {
                        MessageBox.Show("Добавление записи выполнено!", "Успешно");
                        Form ifrm = Application.OpenForms[0];
                        ifrm.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Добавление записи не выполнено!", "Ошибка");
                    }
                }
                else
                {
                    MessageBox.Show("Такое заявление уже существует!!", "Ошибка");
                }
                
            }
        }

        private bool checkForm()
        {
            bool flag = true;

            if(comboBox1.SelectedIndex == -1)
            {
                erSP.SetError(comboBox1, "Не указана специальность!");
                flag = false;
            }

            if (comboBox2.SelectedIndex == -1)
            {
                erFT.SetError(comboBox2, "Не указана форма обучения!");
                flag = false;
            }

            if (comboBox3.SelectedIndex == -1)
            {
                erBT.SetError(comboBox3, "Не указана основа обучения!");
                flag = false;
            }

            return flag;
        }

        private void showFormBasisTraining(int id)
        {
            List<string[]> form = formBasis.selectFormBySpec(id);
            for (int i = 0; i < form.Count; i++)
            {
                comboBox2.Items.Add(form[i][1]);
            }
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();
            //            string s = comboBox1.SelectedText;#
            string s = comboBox1.SelectedItem.ToString();
            int ids = speciality.selectOneByTITLE(s);
            comboBox3.Items.Clear();
            comboBox2.Items.Clear();
            showFormBasisTraining(ids);
        }
            
        private void comboBox2_SelectedValueChanged(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            string s = comboBox2.SelectedItem.ToString();
            int idForm = formBasis.searchForm(s);

            s = comboBox1.SelectedItem.ToString();
            int idSpec = speciality.search(s);

            //F.ID, B.ID, P.IDSpeciality, F.Title, B.Title, P.NumberPlaces
            List<string[]> lst = placeS.selectAll(idSpec);

            for (int i = 0; i < lst.Count; i++)
            {
                int j = Int32.Parse(lst[i][0]);
                if (j == idForm)
                    comboBox3.Items.Add(lst[i][4]);
            }
        }

        //=============================================================SAVE========================================================
        private void saveBUTTON_Click(object sender, EventArgs e)
        {
            if (addorup)
            {
                addInfo();
            }
            else
            {
                updateInfo();
            }
        }
    }
}
