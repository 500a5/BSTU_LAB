﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bddddd.DBClass;

namespace bddddd
{
    public partial class DBComissionMain : Form
    {
        DepartmentDB department = new DepartmentDB();
        SpecialityDB speciality = new SpecialityDB();
        MinScoreDB minscore = new MinScoreDB();
        DisciplineDB discipline = new DisciplineDB();
        PlacesDB places = new PlacesDB();
        FormBasisTraningDB formbasis = new FormBasisTraningDB();
        EntrantDB entran = new EntrantDB();
        PointDB pointDB = new PointDB();
        AchieveDB achieve = new AchieveDB();
        StatementDB statement = new StatementDB();
        int depMod = -1;
        int specMod = -1;
        int disMod = -1;
        int placesMod = -1;
        int idEntrantAll = -1;
        int idDisciplAll = -1;
        int idEntantUP = -1;
        int idStatement = -1;
        int idAchive = -1;
        int tmp = -1;
        bool flAc = false;
        int idAchieve2 = -1;

        public int IdEntrantAll { get => idEntrantAll; set => idEntrantAll = value; }

        private void setAllFalse()
        {
            depMod = -1;
            specMod = -1;
            disMod = -1;
            placesMod = -1;
            idEntrantAll = -1;
            idDisciplAll = -1;
            idEntantUP = -1;
            idStatement = -1;
            idAchive = -1;
            tmp = -1;
            flAc = false;
            idAchieve2 = -1;
        }

        public DBComissionMain()
        {
            InitializeComponent();
            setAllFalse();
        }

        private void set1Tab()
        {
            treeDepartment.Nodes.Clear();          
            showDepartmentTree();
            textBox_Department.Text = "";
            textBox_Speciality.Text = "";
            groupDepartment.Enabled = false;
            groupSpeciality.Enabled = false;
            groupBox_Balls.Enabled = false;
            dataBalls.Enabled = false;
            comboBox_Department.Items.Clear();
            comboBox_Department.Text = "";
            errorTitleDepart.Clear();
            errorComboDep.Clear();
            errorTitleSpec.Clear();
            errorBalls1.Clear();
        }

        private void set2Tab()
        {
            dataPlaces.Rows.Clear();
            treePlaces.Nodes.Clear();
            falsePlacesPad();
        }

        private void set3Tab()
        {
            dataEntrant.Rows.Clear();
            dataAchieveOfEntrant.Rows.Clear();
            dataPointEntrant.Rows.Clear();
            groupBox_EntrAchieve.Enabled = false;
            groupBox_EntrantPoint.Enabled = false;
            showEntrant();
        }

        private void set4Tab()
        {
            dataEntrant2.Rows.Clear();
            dataState.Rows.Clear();
        }

        private void set5Tab()
        {
            poinBox.Clear();
            dostBox.Clear();
            erAC.Clear();
            erPA.Clear();
            groupBox_Achieve_5.Enabled = false;//
            groupBox_Discipline_5.Enabled = false;//
            textBox_Discipline.Clear();//
            errorDiscip.Clear();//
            listBox_Discipline.Items.Clear();//
            dataGridView_ACHIEVE.Rows.Clear(); //
            showAchieve();//
            showDiscipline();//
        }

        private void DBComissionMain_Load(object sender, EventArgs e)
        {
            set2Tab();
            set1Tab();
            set4Tab();
            set3Tab();
            set5Tab();            
        }

        //========================1 вкладка=============================================
        //Показать дисциплины
        private void showDisciplineData(int idSpec)
        {
            List<string[]> discSpec = minscore.selectByID(idSpec); //список предметов для специальости с индексо idSp
            dataBalls.Rows.Clear();
            foreach (string[] s in discSpec)
                dataBalls.Rows.Add(s);        
        }

        //После выбора 
        private void treeDepartment_AfterSelect(object sender, TreeViewEventArgs e)
        {
            int idSpec = speciality.search(e.Node.Text); //нашли ид специальности
            if (idSpec != -1)
                showDisciplineData(idSpec);
        }

        //Показать дисциплины
        private void showDiscipline()
        {
            listBox_Discipline.Items.Clear();
            List<string[]> lst = discipline.selectAll();
            for (int i = 0; i < lst.Count; i++)
            {
                listBox_Discipline.Items.Add(lst[i][0]);
            }
        }

        //Дерево: КАФЕДРА->специальность->проходные баллы по предметам
        private void showDepartmentTree()
        {
            treeDepartment.Nodes.Clear();
            treePlaces.Nodes.Clear();
            List<string[]> lst = department.selectAll();
            for (int i = 0; i < lst.Count; i++)
            {
                TreeNode rn = new TreeNode();
                TreeNode rn2 = new TreeNode();
                rn.Text = lst[i][0];
                rn2.Text = lst[i][0];
                showSpeсialityTree(rn, lst[i][0]); //передали тит кафедры
                showSpeсialityTree2(rn2, lst[i][0]); //передали тит кафедры
                treeDepartment.Nodes.Add(rn);
                treePlaces.Nodes.Add(rn2);
            }
        }

        //Дерево: Кафедра->СПЕЦИАЛЬНОСТЬ->проходные баллы по предметам
        private void showSpeсialityTree(TreeNode root, string spec)
        {
            List<string[]> lst = speciality.selectAll();
            //Dep.Title, S.Title, S.IDDepartment, S.ID
            for (int i = 0; i < lst.Count; i++)
            {
                if (spec == lst[i][0]) //если титл кафедры совпал 
                {//спец, ид кафедры, ид специальности
                    TreeNode rn = new TreeNode();
                    rn.Text = lst[i][1];
                    //showDisciplineTree(rn, lst[i][1]); //title спец
                    root.Nodes.Add(rn);
                }
            }
        }

        //Дерево: Кафедра->СПЕЦИАЛЬНОСТЬ->проходные баллы по предметам
        private void showSpeсialityTree2(TreeNode root, string spec)
        {
            List<string[]> lst = speciality.selectAll();
            //Dep.Title, S.Title, S.IDDepartment, S.ID
            for (int i = 0; i < lst.Count; i++)
            {
                if (spec == lst[i][0]) //если титл кафедры совпал 
                {//спец, ид кафедры, ид специальности
                    TreeNode rn = new TreeNode();
                    rn.Text = lst[i][1];
                    //showDisciplineTree(rn, lst[i][1]); //title спец
                    root.Nodes.Add(rn);
                }
            }
        }

        //Дерево: Кафедра->специальность->ПРОХОДНЫЕ БАЛЛЫ
        private void showDisciplineTree(TreeNode root, string spec)
        {
            List<string[]> lst = minscore.selectAll();
            for (int i = 0; i < lst.Count; i++)
            {
                if (spec == lst[i][0])
                {
                    TreeNode rn = new TreeNode();
                    rn.Text = lst[i][1];
                    //showMinScore(rn, lst[i][2]);
                    root.Nodes.Add(rn);
                }
            }
        }

        //Дерево: Кафедра->специальность->ПРОХОДНЫЕ БАЛЛЫ
        private void showMinScore(TreeNode root, string ball)
        {
            TreeNode rn = new TreeNode();
            rn.Text = ball;
            root.Nodes.Add(rn);
        }

        //Показать кафедры в комбобокс
        private void showDepartmentComboBox()
        {
            List<string[]> lst = department.selectAll();
            for (int i = 0; i < lst.Count; i++)
            {
                comboBox_Department.Items.Add(lst[i][0]);
            }
        }

        //Удалть кафедру
        private void deleteDepartment_Click(object sender, EventArgs e)
        {
            string depTitle;
            try
            {
                depTitle = treeDepartment.SelectedNode.Text;
                int depID = department.search(depTitle);
                if (depID != -1)
                {
                    department.deleteFrom(depID);
                    //showDepartmentTree();
                    set1Tab();
                    MessageBox.Show("Кафедра удалена", "Успешно");
                }
                else
                {
                    MessageBox.Show("Удаление не произошло", "Ошибка");
                }
            }
            catch
            {
                depTitle = "";
                MessageBox.Show("Кафедра не выбрана", "Ошибка");
            }
        }

        //Добавить кафедру
        private void addDepartment_Click(object sender, EventArgs e)
        {
            groupDepartment.Enabled = true;
            depMod = -1;
            textBox_Department.Text = "";
        }

        //Изменение кафедры
        private void updateDepartment_Click(object sender, EventArgs e)
        {
            errorTitleDepart.Clear();
            string title = treeDepartment.SelectedNode.Text;    //Получили имя выбранной кафедры
            int mod = department.search(title);//получили ее id
            if (mod == -1)
            {
                MessageBox.Show("Выбрана не кафедра!", "Ошибка");
            }
            else
            {
                textBox_Department.Text = title;
                groupDepartment.Enabled = true;
                depMod = mod;
            }
        }

        //Удалить специальность
        private void deleteSpeciality_Click(object sender, EventArgs e)
        {
            string spTitle;
            try
            {
                spTitle = treeDepartment.SelectedNode.Text;
                int spID = speciality.search(spTitle);
                if (spID != -1)
                {
                    speciality.deleteFrom(spID);
                    //showDepartmentTree();
                    set1Tab();
                    MessageBox.Show("Специальность удалена", "Успешно");
                }
                else
                {
                    MessageBox.Show("Удаление не произошло", "Ошибка");
                }
            }
            catch
            {
                spTitle = "";
                MessageBox.Show("Специальность не выбрана", "Ошибка");
            }
        }

        //Добавить специальность
        private void addSpecial_Click(object sender, EventArgs e)
        {
            comboBox_Department.Text = "";
            comboBox_Department.Items.Clear();
            errorComboDep.Clear();
            errorTitleSpec.Clear();
            groupSpeciality.Enabled = true;
            specMod = -1;
            textBox_Speciality.Text = "";
            showDepartmentComboBox();
        }

        //Изменить специальность
        private void updateSpec_Click(object sender, EventArgs e)
        {
            errorComboDep.Clear();
            errorTitleSpec.Clear();
            string title;
            try
            {
                title = treeDepartment.SelectedNode.Text;    //Получили имя выбранной спец
                int mod = speciality.search(title); //id спец
                if (mod == -1)
                {
                    MessageBox.Show("Выбрана не специальность!", "Ошибка");
                }
                else
                {
                    showDepartmentComboBox();
                    textBox_Speciality.Text = title;
                    groupSpeciality.Enabled = true;
                    int idDep = speciality.searchIDDepartment(mod); //получили id кафедры
                    string sDep = department.selectOneByID(idDep);//получили title кафедры
                    comboBox_Department.SelectedIndex = comboBox_Department.FindStringExact(sDep);
                    specMod = mod;
                }
            }
            catch
            {
                MessageBox.Show("Ничего не выбрано!", "Ошибка");
            }
        }

        //Добавить для кафедры
        private void saveToDepartment()
        {
            errorTitleDepart.Clear();
            string title = textBox_Department.Text;
            int idDep = -1;
            if (title != "")
            {
                idDep = department.search(title);
                if (idDep == -1)
                {
                    if (department.insertInto(title))
                    {
                        MessageBox.Show("Добавление выполнено", "Успешно");
                        textBox_Department.Text = "";
                        groupDepartment.Enabled = false;
                        errorTitleDepart.Clear();
                        depMod = -1;
                        //showDepartmentTree();
                        set1Tab();
                    }
                    else
                    {
                        MessageBox.Show("Добавление не выполнено", "Ошибка!");
                    }
                }
                else
                {
                    errorTitleDepart.SetError(textBox_Department, "Кафедра существует!");
                }
            }
            else
            {
                errorTitleDepart.SetError(textBox_Department, "Имя не может отсутствовать!");
            }
        }

        //Изменить для кафедры
        private void updaToDepartment()
        {
            errorTitleDepart.Clear();
            string title = textBox_Department.Text;
            if (title != "")
            {
                if (department.updateInfo(title, depMod))
                {
                    MessageBox.Show("Изменение выполнено", "Успешно");
                    textBox_Department.Text = "";
                    groupDepartment.Enabled = false;
                    errorTitleDepart.Clear();
                    depMod = -1;
                    //showDepartmentTree();
                    set1Tab();
                }
                else
                {
                    MessageBox.Show("Данные не были изменены", "Ошибка");
                }
            }
            else
            {
                errorTitleDepart.SetError(textBox_Department, "Имя не может отсутствовать!");
            }
        }

        //Сохранить для кафедры
        private void saveDepartment_Click(object sender, EventArgs e)
        {
            if (depMod == -1)
            {
                saveToDepartment();
            }
            else
            {
                updaToDepartment();
            }
        }

        //Отменить изменения кафедры
        private void cancelDepartment_Click(object sender, EventArgs e)
        {
            set1Tab();
            depMod = -1;
        }

        //Добавить для специальности
        private void saveToSpeciality()
        {
            errorComboDep.Clear();
            errorTitleSpec.Clear();
            if (comboBox_Department.SelectedIndex != -1)
            {
                string title = textBox_Speciality.Text;
                if (title != "")
                {
                    int idSp = speciality.search(title);
                    if (idSp == -1)
                    {
                        int idDep = department.selectOneByTITLE(comboBox_Department.Text);
                        if (speciality.insertInto(title, idDep))
                        {
                            MessageBox.Show("Добавление выполнено", "Успешно");
                            specMod = -1;
                            set1Tab();
                        }
                        else
                        {
                            MessageBox.Show("Добавление не выполнено", "Ошибка!");
                        }
                    }
                    else
                    {
                        errorTitleSpec.SetError(textBox_Speciality, "Такая специальность существует!");
                    }

                }
                else
                {
                    errorTitleSpec.SetError(textBox_Speciality, "Имя не может отсутствовать!");
                }
            }
            else
            {
                errorComboDep.SetError(comboBox_Department, "Кафедра не выбрана!");
            }
        }

        //Изменить для специалбности
        private void updaToSpeciality()
        {
            errorComboDep.Clear();
            errorTitleSpec.Clear();
            string titleSpec = textBox_Speciality.Text;
            string titleDep = comboBox_Department.Text;
            int idDep = department.search(titleDep);
            if (titleSpec != "")
            {
                if (titleDep != "")
                {
                    bool f1 = speciality.updateInfoTITLE(titleSpec, specMod);
                    bool f2 = speciality.updateInfoIDDepartment(titleSpec, idDep);
                    if (f1 && f2)
                    {
                        MessageBox.Show("Изменение выполнено", "Успешно");
                        specMod = -1;
                        set1Tab();
                    }
                    else
                    {
                        MessageBox.Show("Данные не были изменены", "Ошибка");
                    }

                }
                else
                {
                    errorComboDep.SetError(comboBox_Department, "Имя не может отсутствовать!");
                }
            }
            else
            {
                errorTitleSpec.SetError(textBox_Speciality, "Имя не может отсутствовать!");
            }
        }

        //Сохранить для специальности
        private void saveSpeciality_Click(object sender, EventArgs e)
        {
            if (specMod == -1)
            {
                saveToSpeciality();
            }
            else
            {
                updaToSpeciality();
            }
        }

        //Отменить изменения специальности
        private void cancelSpeciality_Click(object sender, EventArgs e)
        {
            set1Tab();
            specMod = -1;
        }

        //Обновить страницу
        private void updateTree_Click(object sender, EventArgs e)
        {
            set1Tab();
        }

        //Добавить предмет баллы
        private void addBalls_Click_1(object sender, EventArgs e)
        {
            Form ae = new AddOrUpdateMINSCORE(textBox_SpecBalls.Text);
            ae.Text = "Добавить баллы";
            ae.Show();
            this.Hide();
        }

        //Удалить баллы
        private void deleteBalls_Click(object sender, EventArgs e)
        {
            try
            {
                string sIdS = dataBalls.SelectedRows[0].Cells["IDS"].Value.ToString();//idspec
                int idS = Int32.Parse(sIdS);//ид специальности
                string sIDD = dataBalls.SelectedRows[0].Cells["IDD"].Value.ToString();//iddisc
                int idD = Int32.Parse(sIDD);//ид дисциплины
                bool flagDel = minscore.deleteFrom(idS, idD); //удаляем
                if (flagDel)
                {
                    MessageBox.Show("Запись удалена!", "Успешно");
                    errorBalls1.Clear();
                    showDisciplineData(idS);
                }
                else
                {
                    MessageBox.Show("Удаление не выполнено!", "Ошибка");
                }
            }
            catch
            {
                errorBalls1.SetError(dataBalls, "Не выбраа строка!");
            }
        }

        //Изменять баллы
        private void modifBalls_Click(object sender, EventArgs e)
        {
            try
            {
                string sSpec = treeDepartment.SelectedNode.Text;
                int idSpec = speciality.search(sSpec);//проверяем, специальность ли это
                if (idSpec == -1)
                {
                    MessageBox.Show("Выбрана не специальность", "Ошибка");
                }
                else
                {
                    showDisciplineData(idSpec);
                    textBox_SpecBalls.Text = sSpec;
                    groupBox_Balls.Enabled = true;
                    dataBalls.Enabled = true;
                }
            }
            catch
            {
                MessageBox.Show("Выбрана не специальность", "Ошибка");
            }
        }

        //изменить баллы
        private void updateBalls_Click_1(object sender, EventArgs e)
        {
            string s = dataBalls.SelectedRows[0].Cells["IDDTitle"].Value.ToString();
            int ball = Int32.Parse(dataBalls.SelectedRows[0].Cells["POINT"].Value.ToString());
            Form ae = new AddOrUpdateMINSCORE(textBox_SpecBalls.Text, s, ball);
            ae.Text = "Изменить баллы";
            ae.Show();
            this.Hide();
        }

        //отмена
        private void otmenaBalls_Click(object sender, EventArgs e)
        {
            groupBox_Balls.Enabled = false;
            dataBalls.Rows.Clear();
            dataBalls.Enabled = false;
            textBox_SpecBalls.Clear();
            notInfoBallsAdd.Clear();
        }

        //========================2 вкладка=============================================
        //Добавить
        private void insertPLACES_Click(object sender, EventArgs e)
        {
            placesMod = -1;
            int idSpe;
            try
            {
                idSpe = speciality.search(treePlaces.SelectedNode.Text);
                if (idSpe != -1)
                {
                    truePlacesPad(); //открыли и записали специальность
                    textBox_PLACES_SPEC.Text = treePlaces.SelectedNode.Text;
                    showFormPLACES();
                    showBasisPLACES();
                    placesMod = -1;
                }
            }
            catch
            {
                MessageBox.Show("Не выбрана специальность!", "Ошибка!");
            }
        }

        //Показать специальности для добавления
        private void showFormPLACES()
        {
            List<string[]> lst1 = formbasis.selectForm(); //выбрали все формы
            for (int i = 0; i < lst1.Count; i++)
                comboBox_PLACES_FORM.Items.Add(lst1[i][1]);
        }
        
        //Показать специальности для добавления
        private void showBasisPLACES()
        {
            List<string[]> lst1 = formbasis.selectBasis(); //выбрали все формы
            for (int i = 0; i < lst1.Count; i++)
                comboBox_PLACES_BASIS.Items.Add(lst1[i][1]);
        }

        //Показать места на определенную спец
        private void showPlacesData(int idSp)
        {
            dataPlaces.Rows.Clear(); //почистили
            List<string[]> lst = places.selectAll(idSp);
            foreach (string[] s in lst)
                dataPlaces.Rows.Add(s);
        }

        //обновить
        private void updatePLACES_Click(object sender, EventArgs e)
        {
            int idSpe;
            try
            {
                idSpe = speciality.search(treePlaces.SelectedNode.Text);
                if (idSpe != -1)
                {
                    truePlacesPad(); //открыли и записали специальность
                    textBox_PLACES_SPEC.Text = treePlaces.SelectedNode.Text;
                    showFormPLACES();
                    showBasisPLACES();
                    comboBox_PLACES_BASIS.SelectedIndex = comboBox_PLACES_BASIS.FindStringExact(dataPlaces.SelectedRows[0].Cells["TItleBT"].Value.ToString());
                    comboBox_PLACES_FORM.SelectedIndex = comboBox_PLACES_FORM.FindStringExact(dataPlaces.SelectedRows[0].Cells["TitleFT"].Value.ToString());
                    textBox_PLACES_NUMB.Text = dataPlaces.SelectedRows[0].Cells["NUM"].Value.ToString();
                    placesMod = idSpe;
                }
            }
            catch
            {
                MessageBox.Show("Не выбрана специальность!", "Ошибка!");
            }
        }

        //Удалить
        private void deletePLACES_Click(object sender, EventArgs e)
        {
            string s = dataPlaces.SelectedRows[0].Cells["IDFT"].Value.ToString();
            int idFt = Int32.Parse(s);
            s = dataPlaces.SelectedRows[0].Cells["IDBT"].Value.ToString();
            int idbt = Int32.Parse(s);
            s = dataPlaces.SelectedRows[0].Cells["IDSPEC"].Value.ToString();
            int idsp = Int32.Parse(s);
            if (places.deletFrom(idsp, idFt, idbt))
            {
                MessageBox.Show("Выполнено удаление", "Успешно");
                showDepartmentTree();
                showPlacesData(idsp);
                falsePlacesPad();
            }
            else
            {
                MessageBox.Show("Удаление не было выполнено", "Ошибка");
            }
        }

        //обновить
        private void obnovaPLACES_Click(object sender, EventArgs e)
        {
            set2Tab();
            set1Tab();
            placesMod = -1;
        }

        //Проверяет, существует ли такая информация
        private bool chekThisInfo(string ft, string bt, int idSpec)
        {
            List<string[]> lst1 = places.selectAll(idSpec);
            for (int i = 0; i < lst1.Count; i++)
            {
                if (lst1[i][3] == ft)
                {
                    if (bt == lst1[i][4])
                        return true;
                }
            }
            return false;
        }

        //Добавить для мест
        private void saveToInsertPlaces()
        {
            if (comboBox_PLACES_BASIS.SelectedIndex == -1) //основа?
            {
                erBASISTRANING.SetError(comboBox_PLACES_BASIS, "Не выбрана основа!");
            }
            else
            {
                if (comboBox_PLACES_FORM.SelectedIndex == -1)//форма?
                {
                    erFORMTRANING.SetError(comboBox_PLACES_FORM, "Не выбрана форма!");
                }
                else
                {
                    if (textBox_PLACES_NUMB.Text == "")//Пусто?
                    {
                        erNUMPLACES.SetError(textBox_PLACES_NUMB, "Не указанно количество мест!");
                    }
                    else
                    {
                        int inum = -1;
                        if (Int32.TryParse(textBox_PLACES_NUMB.Text, out inum))
                        {
                            if (inum <= 0)
                            {
                                erNUMPLACES.SetError(textBox_PLACES_NUMB, "Количество мест должно быть больше нуля!");
                            }
                            else
                            {
                                int idSpec = speciality.search(textBox_PLACES_SPEC.Text);
                                bool flag = chekThisInfo(comboBox_PLACES_FORM.Text, comboBox_PLACES_BASIS.Text, idSpec);
                                if (flag)
                                {
                                    MessageBox.Show("Запись существует!", "Ошибка");
                                }
                                else
                                {
                                    int idForm = formbasis.searchForm(comboBox_PLACES_FORM.Text);
                                    int idBasis = formbasis.searchBasis(comboBox_PLACES_BASIS.Text);
                                    if (places.insertInto(idSpec, idForm, idBasis, inum))
                                    {
                                        MessageBox.Show("Выполнено добавление", "Успешно");
                                        //showDepartmentTree();
                                        dataPlaces.Rows.Clear();
                                        showPlacesData(idSpec);
                                        falsePlacesPad();
                                        placesMod = -1;
                                    }
                                    else
                                    {
                                        MessageBox.Show("Не выполнено добавление", "Ошибка");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        //Изменить для мест
        private void saveToUpdatePlaces()
        {
            if (comboBox_PLACES_BASIS.SelectedIndex == -1)
            {
                erBASISTRANING.SetError(comboBox_PLACES_BASIS, "Не выбрана основа!");
            }
            else
            {
                if (comboBox_PLACES_FORM.SelectedIndex == -1)
                {
                    erFORMTRANING.SetError(comboBox_PLACES_FORM, "Не выбрана форма!");
                }
                else
                {
                    if (textBox_PLACES_NUMB.Text == "")
                    {
                        erNUMPLACES.SetError(textBox_PLACES_NUMB, "Не указанно количество мест!");
                    }
                    else
                    {
                        int inum = -1;
                        if (Int32.TryParse(textBox_PLACES_NUMB.Text, out inum))
                        {
                            if (inum <= 0)
                            {
                                erNUMPLACES.SetError(textBox_PLACES_NUMB, "Количество мест должно быть больше нуля!");
                            }
                            else
                            {
                                int idSpec = speciality.search(textBox_PLACES_SPEC.Text);
                                int idForm = formbasis.searchForm(comboBox_PLACES_FORM.Text);
                                int idBasis = formbasis.searchBasis(comboBox_PLACES_BASIS.Text);
                                bool up1 = places.updateInfoNUMB(idSpec, idForm, idBasis, inum);
                                bool up2 = places.updateInfoBASISTRANING(idSpec, idForm, idBasis, inum);
                                bool up3 = places.updateInfoFORMTRANING(idSpec, idForm, idBasis, inum);
                                if (up1 && up2 && up3)
                                {
                                    MessageBox.Show("Выполнено изменение", "Успешно");
                                    //showDepartmentTree();
                                    dataPlaces.Rows.Clear();
                                    showPlacesData(idSpec);
                                    falsePlacesPad();
                                    placesMod = -1;
                                }
                                else
                                {
                                    MessageBox.Show("Не выполнено добавление", "Ошибка");
                                }

                            }
                        }
                        else
                        {
                            erNUMPLACES.SetError(textBox_PLACES_NUMB, "Это не число!");
                        }
                    }
                }

            }
        }

        //Сохранить
        private void savePLACES_Click(object sender, EventArgs e)
        {
            erBASISTRANING.Clear();
            erFORMTRANING.Clear();
            erNUMPLACES.Clear();
            if (placesMod == -1)
            {
                saveToInsertPlaces();
            }
            else
            {
                saveToUpdatePlaces();
            }
            placesMod = -1;
        }

        //отмена заполнения
        private void otmenaPLACES_Click(object sender, EventArgs e)
        {
            falsePlacesPad();
        }

        //Нажали на специальность
        private void treePlaces_AfterSelect(object sender, TreeViewEventArgs e)
        {
            int idSpec = speciality.search(e.Node.Text); //нашли ид специальности
            if (idSpec != -1)
                showPlacesData(idSpec);
        }

        //все в фалс
        private void falsePlacesPad()
        {
            PLACESBOX.Enabled = false;
            comboBox_PLACES_BASIS.Text = "";
            comboBox_PLACES_BASIS.Items.Clear();
            comboBox_PLACES_FORM.Text = "";
            comboBox_PLACES_FORM.Items.Clear();
            textBox_PLACES_NUMB.Clear();
            textBox_PLACES_SPEC.Clear();
            erBASISTRANING.Clear();
            erFORMTRANING.Clear();
            erNUMPLACES.Clear();
        }

        //в труе
        private void truePlacesPad()
        {
            PLACESBOX.Enabled = true;
            comboBox_PLACES_BASIS.Text = "";
            comboBox_PLACES_BASIS.Items.Clear();
            comboBox_PLACES_FORM.Text = "";
            comboBox_PLACES_FORM.Items.Clear();
            textBox_PLACES_NUMB.Clear();
            textBox_PLACES_SPEC.Clear();
            erBASISTRANING.Clear();
            erFORMTRANING.Clear();
            erNUMPLACES.Clear();
        }

        //========================3 вкладка=============================================
        //Вывод таблицы абитуриентв
        private void showEntrant()
        {
            dataEntrant.Rows.Clear(); //почистили
            dataEntrant2.Rows.Clear(); //почистили
            List<string[]> las = entran.selectAll();
            foreach (string[] s in las)
            {
                dataEntrant.Rows.Add(s);
                dataEntrant2.Rows.Add(s);
            }
        }

        //Добавить абитуриента
        private void addEnt_Click(object sender, EventArgs e)
        {
            Form ae = new AddOrUpdateENTRANT();
            ae.Text = "Добавить абитуриента";
            ae.Show();
            this.Hide();
        }

        //Изменить абитуриента
        private void upEnt_Click(object sender, EventArgs e)
        {
            string s = dataEntrant.SelectedRows[0].Cells["ID"].Value.ToString();
            int id = Int32.Parse(s);
            Form ae = new AddOrUpdateENTRANT(id);
            ae.Text = "Изменить абитуриента";
            ae.Show();
            this.Hide();
        }

        //Удалить абитуриента
        private void delEnt_Click(object sender, EventArgs e)
        {
            string s = dataEntrant.SelectedRows[0].Cells["ID"].Value.ToString();
            int id = Int32.Parse(s);
            if (entran.deleteFrom(id))
                MessageBox.Show("Удаление выполнено", "Успешно");
            else
                MessageBox.Show("Удаление не выполнено", "Ошибка!");
            showEntrant();
        }

        //Подсветить конкретного
        private void dataEntrant_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataEntrant.SelectedRows[0].Cells["ID"].Value.ToString();
            int id = Int32.Parse(s);
            groupBox_EntrantPoint.Enabled = false;
            groupBox_EntrAchieve.Enabled = false;
            tmp = id;
            shoeMyAchieve(id);
            showEntrantPoint(id);
        }

        //Изменить достижения
        private void modAchieve_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            comboBox_RealAchieve.Items.Clear();
            groupBox_EntrAchieve.Enabled = true;
            string s = dataEntrant.SelectedRows[0].Cells["ID"].Value.ToString();
            int id = Int32.Parse(s);
            textBox1.Text = s;
            List<string[]> lst = achieve.selectByEntrant(id);//для одного вбитуриента
            List<string[]> ls2 = achieve.selectAll();//для одного вбитуриента
            bool flag = false;
            for (int i = 0; i < ls2.Count; i++)
            {
                for (int j = 0; j < lst.Count; j++)
                {
                    if (ls2[i][0] == lst[j][0])
                        flag = true;
                }
                if (flag != true)
                    comboBox_RealAchieve.Items.Add(ls2[i][1]);
                flag = false;
            }
        }

        //Щелчок по достижениям амбтуриента
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataAchieveOfEntrant.SelectedRows[0].Cells["IDac"].Value.ToString();
            int IDac = Int32.Parse(s);
            idAchive = IDac;
        }

        //ДДобавить достижение
        private void updateToEntrantAc_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            try
            {
                string s = comboBox_RealAchieve.SelectedItem.ToString();
                if (s == "")
                {
                    errorProvider1.SetError(comboBox_RealAchieve, "Не выбрано достижение!");
                }
                else
                {
                    int a = achieve.searchId(s);
                    achieve.insertIntoByEntrant(Int32.Parse(textBox1.Text), a);
                    shoeMyAchieve(Int32.Parse(textBox1.Text));
                    comboBox_RealAchieve.Items.Clear();
                    comboBox_RealAchieve.Text = "";
                    idAchive = -1;
                    groupBox_EntrAchieve.Enabled = false;
                    comboBox_RealAchieve.Items.Clear();
                }
            }
            catch
            {
                errorProvider1.SetError(comboBox_RealAchieve, "Не выбрано достижение!");
            }
            
        }

        //Удалить достижение
        private void button_DelAchieveOfEntrant_Click(object sender, EventArgs e)
        {
            if (idAchive != -1)
            {
                int idEnt = Int32.Parse(dataAchieveOfEntrant.SelectedRows[0].Cells["IDEN"].Value.ToString());
                if (achieve.deleteFromByEntrant(idEnt, idAchive))
                {
                    MessageBox.Show("Достижение удалено", "Успешно");
                    shoeMyAchieve(idEnt);
                    groupBox_EntrAchieve.Enabled = false;
                }
                else if (tmp != idEnt)
                        MessageBox.Show("Достижение нужно выбрать абитуриента", "Ошибка");
            }
            else
            {
                MessageBox.Show("Выберите строку с достижением для удаления ещё раз", "Ошибка");
            }
            tmp = -1;
            idAchive = -1;
        }

        //отмена для достижений абитуриента
        private void button12_Click(object sender, EventArgs e)
        {
            groupBox_EntrAchieve.Enabled = false;
            comboBox_RealAchieve.Items.Clear();
            idAchive = -1;
        }
        
        //Достижения абитуриента
        private void shoeMyAchieve(int id)
        {
            dataAchieveOfEntrant.Rows.Clear();
            List<string[]> lst = achieve.selectByEntrant2(id);
            foreach (string[] s in lst)
                dataAchieveOfEntrant.Rows.Add(s);
        }

        //Изменить баллы
        private void button2_Click(object sender, EventArgs e)
        {
            groupBox_EntrantPoint.Enabled = true;
        }

        //Клик по баллам
        private void dataPointEntrant_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataPointEntrant.SelectedRows[0].Cells["IDEntrant"].Value.ToString();
            int idEnt = Int32.Parse(s);
            idEntrantAll = idEnt;
            s = dataPointEntrant.SelectedRows[0].Cells["IDDiscipline"].Value.ToString();
            int idDisc = Int32.Parse(s);
            idDisciplAll = idDisc;
        }

        //Показать баллы
        private void showEntrantPoint(int id)
        {
            dataPointEntrant.Rows.Clear();
            List<string[]> lst = pointDB.selectByEntrant(id);
            foreach (string[] s in lst)
                dataPointEntrant.Rows.Add(s);
        }

        //Добавить
        private void addPoint_Click(object sender, EventArgs e)
        {
            try
            {
                string s = dataEntrant.SelectedRows[0].Cells["ID"].Value.ToString();
                int id = Int32.Parse(s);
                Form ae = new AddOrUpdateEntrantPoint(id, true);
                ae.Text = "Добавить баллы абитуриента";
                ae.Show();
                this.Hide();
            }
            catch
            {
                MessageBox.Show("Не выбран абитуриент", "Ошибка!");
            }
        }

        //Изменить баллы
        private void updatePoint_Click(object sender, EventArgs e)
        {
            try
            {
                string s;
                int id, idDisc;
                s = dataEntrant.SelectedRows[0].Cells["ID"].Value.ToString();
                id = Int32.Parse(s);
                s = dataPointEntrant.SelectedRows[0].Cells["IDDiscipline"].Value.ToString();
                idDisc = Int32.Parse(s);
                bool flag = false;
                Form ae = new AddOrUpdateEntrantPoint(id, flag, idDisc);
                ae.Text = "Изменить баллы абитуриента";
                ae.Show();
                this.Hide();
            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("Строка не выбрана или отсутствует!", "Ошибка!");
            }
        }

        //Удалить балл
        private void deletePoint_Click(object sender, EventArgs e)
        {
            if (idEntrantAll == -1 && idDisciplAll == -1)
            {
                MessageBox.Show("Необходимо повторить выбор строки таблицы, содержащей баллы", "Внимание!");
            }
            else
            {
                if (pointDB.deleteFrom(idDisciplAll, idEntrantAll))
                {
                    MessageBox.Show("Удаление выполнено", "Успешно!");
                    showEntrantPoint(idEntrantAll);
                    idEntrantAll = -1;
                    idDisciplAll = -1;
                    groupBox_EntrantPoint.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Удаление не выполнено", "Ошибка!");
                    idEntrantAll = -1;
                    idDisciplAll = -1;
                }
            }
        }

        //Отмена для баллов
        private void button3_Click(object sender, EventArgs e)
        {
            groupBox_EntrantPoint.Enabled = false;
            idEntrantAll = -1;
            idDisciplAll = -1;
        }

        //Обновить
        private void button1_Click(object sender, EventArgs e)
        {
            set4Tab();
            set3Tab();
            idEntrantAll = -1;
            idDisciplAll = -1;
            tmp = -1;
            idAchive = -1;
        }

        //========================4 вкладка=============================================
        //Щелчек по абитуриенту
        private void dataEntrant2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataEntrant2.SelectedRows[0].Cells["ID2"].Value.ToString();
            int idEnt = Int32.Parse(s);
            showStatements(idEnt);
            idEntrantAll = idEnt;
        }

        //Щелчок по заявлению
        private void dataState_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idStatement = -1;
            idEntantUP = -1;
            string s = dataState.SelectedRows[0].Cells["IDStat"].Value.ToString();
            int id = Int32.Parse(s);

            s = dataState.SelectedRows[0].Cells["IDEntr"].Value.ToString();
            int idE = Int32.Parse(s);

            idStatement = id;
            idEntantUP = idE;
        }

        //Добавить заявление
        private void addStat_Click(object sender, EventArgs e)
        {
            if (idEntrantAll == -1)
            {
                MessageBox.Show("Необходимо выбрать абитуриента, которому нужно добавить заявление", "Внимание!");
            }
            else
            {
                int count = statement.countOfStateEntrant(idEntrantAll);

                if (count < 3)
                {
                    bool con = statement.checkConsent(idEntrantAll);
                    bool og = statement.checkOriginalDoc(idEntrantAll);
                    Form ae = new AddOrUpdateStatement(idEntrantAll, con, og, true);
                    idStatement = -1;
                    idEntrantAll = -1;
                    ae.Text = "Добавить заявление";
                    ae.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("У абитуриента имеется три заявления! Добавление не возможно", "Внимание!");
                    idStatement = -1;
                    idEntrantAll = -1;
                }
            }

        }

        //Изменить заявление
        private void updatButton_Click(object sender, EventArgs e)
        {
            if (idStatement == -1 && idEntantUP == -1)
            {
                MessageBox.Show("Необходимо выбрать заявление!", "Внимание!");
                idStatement = -1;
                idEntantUP = -1;
            }
            else
            {                
                Form ae = new AddOrUpdateStatement(idEntantUP, idStatement, false);
                ae.Text = "Изменить заявления";
                ae.Show();
                this.Hide();
            }
        }

        //Удалить заявление
        private void delStat_Click(object sender, EventArgs e)
        {
            if (idStatement != -1)
            {
                if (statement.deleteFrom(idStatement))
                {
                    MessageBox.Show("Удаление выполнено", "Успешно");
                    string s = dataEntrant2.SelectedRows[0].Cells["ID2"].Value.ToString();
                    int idEnt = Int32.Parse(s);
                    dataState.Rows.Clear();
                    showStatements(idEnt);
                    idStatement = -1;
                }

                else
                    MessageBox.Show("Удаление не выполнено", "Ошибка!");
                showEntrant();
                idStatement = -1;
                idEntrantAll = -1;
            }

        }

        //Обновить
        private void button4_Click(object sender, EventArgs e)
        {
            set4Tab();
            set3Tab();
            idEntrantAll = -1;
            idDisciplAll = -1;
            idStatement = -1;
        }

        //Заявление по айди
        private void showStatements(int id)
        {
            dataState.Rows.Clear();
            List<string[]> lst = statement.selectByEntrant(id);
            foreach (string[] s in lst)
                dataState.Rows.Add(s);
        }

        //========================5 вкладка=============================================
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataGridView_ACHIEVE.SelectedRows[0].Cells["IDdost"].Value.ToString();// выбрали айди достижения
            int id = Int32.Parse(s);
            idAchieve2 = id;
        }

        //Добавить достижение
        private void button5_Click(object sender, EventArgs e)
        {
            poinBox.Clear();
            dostBox.Clear();
            erAC.Clear();
            erPA.Clear();
            groupBox_Achieve_5.Enabled = true;
            flAc = false;
        }

        //Изменить достижение
        private void button6_Click(object sender, EventArgs e)
        {
            poinBox.Clear();
            dostBox.Clear();
            erAC.Clear();
            erPA.Clear();
            groupBox_Achieve_5.Enabled = true;
            flAc = true;
            dostBox.Text = dataGridView_ACHIEVE.SelectedRows[0].Cells["TitleDOST"].Value.ToString();
            poinBox.Text = dataGridView_ACHIEVE.SelectedRows[0].Cells["PointDOST"].Value.ToString();
        }

        //Удалить достижение
        private void button7_Click(object sender, EventArgs e)
        {
            if (idAchieve2 != -1)
            {
                if (achieve.deleteFrom(idAchieve2))
                {
                    MessageBox.Show("Удалени выполнено!", "Успешно!");
                    dataGridView_ACHIEVE.Rows.Clear();
                    showAchieve();
                }
            }
            else
                MessageBox.Show("Не выбрано достижение для удаления!", "Ошибка!");
            idAchieve2 = -1;
        }

        //Изменить достижение
        private void updateAchieve()
        {
            erPA.Clear();
            erAC.Clear();
            int bal;
            string s = poinBox.Text;
            if (s == "")
            {
                erPA.SetError(poinBox, "Не введены баллы!");
            }
            else
            {
                if (Int32.TryParse(poinBox.Text, out bal))
                {
                    if (bal < 1 || bal > 10)
                    {
                        erPA.SetError(poinBox, "Дополнительные баллы должны находиться в предалах от 1 до 10!");
                    }
                    else
                    {
                        s = dostBox.Text;
                        if (s == "")
                        {
                            erAC.SetError(dostBox, "Не указано наименование достижения!");
                        }
                        else
                        {
                            if (achieve.updateInfo(idAchieve2, dostBox.Text, bal))
                            {
                                erAC.Clear();
                                erPA.Clear();
                                groupBox_Achieve_5.Enabled = false;
                                poinBox.Clear();
                                dostBox.Clear();
                                MessageBox.Show("Изменена информация о личном достижении!", "Успешно!");
                                groupBox_Achieve_5.Enabled = false;
                                showAchieve();
                            }
                            else
                            {
                                MessageBox.Show("Не изменена информация о личном достижении!", "Ошибка!");
                            }

                        }
                    }
                }
                else
                {
                    erPA.SetError(poinBox, "Это не число!");
                }
            }
            idAchieve2 = -1;
        }

        //Добавить достижение
        private void saveAchieve()
        {
            erPA.Clear();
            erAC.Clear();
            int bal;
            string s = poinBox.Text;
            if (s == "")
            {
                erPA.SetError(poinBox, "Не введены баллы!");
            }
            else
            {
                if (Int32.TryParse(poinBox.Text, out bal))
                {
                    if (bal < 1 || bal > 10)
                    {
                        erPA.SetError(poinBox, "Дополнительные баллы должны находиться в предалах от 1 до 10!");
                    }
                    else
                    {
                        s = dostBox.Text;
                        if (s == "")
                        {
                            erAC.SetError(dostBox, "Не указано наименование достижения!");
                        }
                        else
                        {
                            if (achieve.insertInto(dostBox.Text, bal))
                            {
                                erAC.Clear();
                                erPA.Clear();
                                MessageBox.Show("Добавлена информация о личном достижении!", "Успешно!");
                                groupBox_Achieve_5.Enabled = false;
                                poinBox.Clear();
                                dostBox.Clear();
                                showAchieve();
                            }
                            else
                            {
                                MessageBox.Show("Не добавлена информация о личном достижении!", "Ошибка!");
                            }
                        }
                    }
                }
                else
                {
                    erPA.SetError(poinBox, "Это не число!");
                }
            }
        }

        //Сохраниеть достижения
        private void button8_Click(object sender, EventArgs e)
        {
            if (flAc == false)
                saveAchieve();
            if (flAc == true)
                updateAchieve();
            dataGridView_ACHIEVE.Rows.Clear();
            showAchieve();
        }

        //Отмена достижения
        private void button9_Click(object sender, EventArgs e)
        {
            poinBox.Clear();
            dostBox.Clear();
            erAC.Clear();
            erPA.Clear();
            groupBox_Achieve_5.Enabled = false;
        }

        //Показать достижения
        private void showAchieve()
        {
            dataGridView_ACHIEVE.Rows.Clear();
            List<string[]> lst = achieve.selectAll();
            foreach (string[] s in lst)
                dataGridView_ACHIEVE.Rows.Add(s);
        }

        //Добавить дисциплину
        private void addDiscipl_Click_1(object sender, EventArgs e)
        {
            groupBox_Discipline_5.Enabled = true;
            textBox_Discipline.Text = "";
            disMod = -1;
            errorDiscip.Clear();
        }

        //Изменить дисциплину
        private void updateDiscipl_Click_1(object sender, EventArgs e)
        {
            errorDiscip.Clear();
            try
            {
                textBox_Discipline.Text = listBox_Discipline.SelectedItem.ToString();
                groupBox_Discipline_5.Enabled = true;
                int idDis = discipline.searchId(textBox_Discipline.Text);
                disMod = idDis;
            }
            catch
            {
                MessageBox.Show("Дисциплина не выбрана", "Ошибка!");
            }
        }

        //Удалить дисциплину
        private void deleteDisc_Click_1(object sender, EventArgs e)
        {
            string sDis;
            try
            {
                sDis = listBox_Discipline.SelectedItem.ToString();
                if (sDis != "")
                {
                    int idDis = discipline.searchId(sDis);
                    if (idDis != -1)
                    {
                        if (discipline.deletFrom(idDis))
                        {
                            MessageBox.Show("Дисциплина удалена", "Успешно");
                            showDiscipline();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Удаление не произошло", "Ошибка");
                    }
                }
                else
                {
                    MessageBox.Show("Дисциплина не выбрана", "Ошибка!");
                }
            }
            catch
            {
                MessageBox.Show("Дисциплина не выбрана", "Ошибка!");
            }
        }

        //Отмена для дисциплины
        private void otmenaDisci_Click_1(object sender, EventArgs e)
        {
            groupBox_Discipline_5.Enabled = false;
            textBox_Discipline.Text = "";
            disMod = -1;
            errorDiscip.Clear();
        }

        //добавиь для дисциплины
        private void insertToDiscipline()
        {
            if (textBox_Discipline.Text != "")
            {
                int idDis = discipline.searchId(textBox_Discipline.Text);
                if (idDis == -1)
                {
                    if (discipline.insertInto(textBox_Discipline.Text))
                    {
                        groupBox_Discipline_5.Enabled = false;
                        textBox_Discipline.Text = "";
                        disMod = -1;
                        errorDiscip.Clear();
                        showDiscipline();
                        MessageBox.Show("Выполнено добавление", "Успешно");
                    }
                }
                else
                {
                    errorDiscip.SetError(textBox_Discipline, "Дисциплина уже существует!");
                }
            }
            else
            {
                errorDiscip.SetError(textBox_Discipline, "Имя не может быть пустым!");
            }
        }

        //Изменить для дисциплины
        private void updateToDiscipline()
        {
            errorDiscip.Clear();
            string title = textBox_Discipline.Text;
            if (title != "")
            {
                if (discipline.updateInfo(title, disMod))
                {
                    MessageBox.Show("Изменение выполнено", "Успешно");
                    textBox_Discipline.Text = "";
                    errorDiscip.Clear();
                    disMod = -1;
                    groupBox_Discipline_5.Enabled = false;
                    showDiscipline();
                }
                else
                {
                    MessageBox.Show("Данные не были изменены", "Ошибка");
                }
            }
            else
            {
                errorDiscip.SetError(textBox_Department, "Имя не может отсутствовать!");
            }
        }

        //Сохраинить для дисциплины
        private void saveDisc_Click_1(object sender, EventArgs e)
        {
            if (disMod == -1)
            {
                insertToDiscipline();
            }
            if (disMod != -1)
            {
                updateToDiscipline();
            }
        }

        //Обновить
        private void button10_Click(object sender, EventArgs e)
        {
            set5Tab();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            set4Tab();
            set3Tab();
        }
    }

}