﻿namespace bddddd
{
    partial class DBComissionMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.modifBalls = new System.Windows.Forms.Button();
            this.groupBox_Balls = new System.Windows.Forms.GroupBox();
            this.textBox_SpecBalls = new System.Windows.Forms.TextBox();
            this.updateBalls = new System.Windows.Forms.Button();
            this.addBalls = new System.Windows.Forms.Button();
            this.deleteBalls = new System.Windows.Forms.Button();
            this.dataBalls = new System.Windows.Forms.DataGridView();
            this.IDD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDDTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POINT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updateSpec = new System.Windows.Forms.Button();
            this.addSpecial = new System.Windows.Forms.Button();
            this.groupSpeciality = new System.Windows.Forms.GroupBox();
            this.cancelSpeciality = new System.Windows.Forms.Button();
            this.saveSpeciality = new System.Windows.Forms.Button();
            this.textBox_Speciality = new System.Windows.Forms.TextBox();
            this.comboBox_Department = new System.Windows.Forms.ComboBox();
            this.updateDepartment = new System.Windows.Forms.Button();
            this.addDepartment = new System.Windows.Forms.Button();
            this.groupDepartment = new System.Windows.Forms.GroupBox();
            this.cancelDepartment = new System.Windows.Forms.Button();
            this.saveDepartment = new System.Windows.Forms.Button();
            this.textBox_Department = new System.Windows.Forms.TextBox();
            this.updateTree = new System.Windows.Forms.Button();
            this.deleteSpeciality = new System.Windows.Forms.Button();
            this.deleteDepartment = new System.Windows.Forms.Button();
            this.treeDepartment = new System.Windows.Forms.TreeView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.obnovaPLACES = new System.Windows.Forms.Button();
            this.deletePLACES = new System.Windows.Forms.Button();
            this.updatePLACES = new System.Windows.Forms.Button();
            this.insertPLACES = new System.Windows.Forms.Button();
            this.PLACESBOX = new System.Windows.Forms.GroupBox();
            this.textBox_PLACES_SPEC = new System.Windows.Forms.TextBox();
            this.savePLACES = new System.Windows.Forms.Button();
            this.otmenaPLACES = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_PLACES_NUMB = new System.Windows.Forms.TextBox();
            this.comboBox_PLACES_BASIS = new System.Windows.Forms.ComboBox();
            this.comboBox_PLACES_FORM = new System.Windows.Forms.ComboBox();
            this.dataPlaces = new System.Windows.Forms.DataGridView();
            this.IDFT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDBT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDSPEC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TitleFT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TItleBT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treePlaces = new System.Windows.Forms.TreeView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.modAchieve = new System.Windows.Forms.Button();
            this.groupBox_EntrantPoint = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.updatePoint = new System.Windows.Forms.Button();
            this.addPoint = new System.Windows.Forms.Button();
            this.deletePoint = new System.Windows.Forms.Button();
            this.dataPointEntrant = new System.Windows.Forms.DataGridView();
            this.IDEntrant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDDiscipline = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TitleDiscipline = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PointD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox_EntrAchieve = new System.Windows.Forms.GroupBox();
            this.button_DelAchieveOfEntrant = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.dataAchieveOfEntrant = new System.Windows.Forms.DataGridView();
            this.IDac = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDEN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAMEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.poii = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox_RealAchieve = new System.Windows.Forms.ComboBox();
            this.updateToEntrantAc = new System.Windows.Forms.Button();
            this.upEnt = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.delEnt = new System.Windows.Forms.Button();
            this.addEnt = new System.Windows.Forms.Button();
            this.dataEntrant = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.INAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pasp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Adr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DBer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Con = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Host = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.delStat = new System.Windows.Forms.Button();
            this.updatButton = new System.Windows.Forms.Button();
            this.addStat = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataEntrant2 = new System.Windows.Forms.DataGridView();
            this.ID2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataState = new System.Windows.Forms.DataGridView();
            this.IDStat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDEntr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDSpecial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDForm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDBasis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TitleSpec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TitleForm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TitleBas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Consent = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.OD = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dataGridView_ACHIEVE = new System.Windows.Forms.DataGridView();
            this.IDdost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TitleDOST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PointDOST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button10 = new System.Windows.Forms.Button();
            this.groupBox_Achieve_5 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.poinBox = new System.Windows.Forms.TextBox();
            this.dostBox = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox_Discipline_5 = new System.Windows.Forms.GroupBox();
            this.textBox_Discipline = new System.Windows.Forms.TextBox();
            this.otmenaDisci = new System.Windows.Forms.Button();
            this.saveDisc = new System.Windows.Forms.Button();
            this.updateDiscipl = new System.Windows.Forms.Button();
            this.addDiscipl = new System.Windows.Forms.Button();
            this.deleteDisc = new System.Windows.Forms.Button();
            this.listBox_Discipline = new System.Windows.Forms.ListBox();
            this.button5 = new System.Windows.Forms.Button();
            this.errorTitleDepart = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorComboDep = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorTitleSpec = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorDiscip = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorBalls1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.notInfoBallsAdd = new System.Windows.Forms.ErrorProvider(this.components);
            this.erFORMTRANING = new System.Windows.Forms.ErrorProvider(this.components);
            this.erBASISTRANING = new System.Windows.Forms.ErrorProvider(this.components);
            this.erNUMPLACES = new System.Windows.Forms.ErrorProvider(this.components);
            this.erAC = new System.Windows.Forms.ErrorProvider(this.components);
            this.erPA = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.button11 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox_Balls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBalls)).BeginInit();
            this.groupSpeciality.SuspendLayout();
            this.groupDepartment.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.PLACESBOX.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataPlaces)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox_EntrantPoint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataPointEntrant)).BeginInit();
            this.groupBox_EntrAchieve.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataAchieveOfEntrant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataEntrant)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataEntrant2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataState)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ACHIEVE)).BeginInit();
            this.groupBox_Achieve_5.SuspendLayout();
            this.groupBox_Discipline_5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorTitleDepart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorComboDep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorTitleSpec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorDiscip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBalls1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notInfoBallsAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erFORMTRANING)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erBASISTRANING)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erNUMPLACES)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erAC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erPA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(1, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(730, 482);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.modifBalls);
            this.tabPage1.Controls.Add(this.groupBox_Balls);
            this.tabPage1.Controls.Add(this.updateSpec);
            this.tabPage1.Controls.Add(this.addSpecial);
            this.tabPage1.Controls.Add(this.groupSpeciality);
            this.tabPage1.Controls.Add(this.updateDepartment);
            this.tabPage1.Controls.Add(this.addDepartment);
            this.tabPage1.Controls.Add(this.groupDepartment);
            this.tabPage1.Controls.Add(this.updateTree);
            this.tabPage1.Controls.Add(this.deleteSpeciality);
            this.tabPage1.Controls.Add(this.deleteDepartment);
            this.tabPage1.Controls.Add(this.treeDepartment);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(722, 456);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Кафедры и специальности";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // modifBalls
            // 
            this.modifBalls.Location = new System.Drawing.Point(320, 167);
            this.modifBalls.Name = "modifBalls";
            this.modifBalls.Size = new System.Drawing.Size(141, 23);
            this.modifBalls.TabIndex = 20;
            this.modifBalls.Text = "Изменить баллы";
            this.modifBalls.UseVisualStyleBackColor = true;
            this.modifBalls.Click += new System.EventHandler(this.modifBalls_Click);
            // 
            // groupBox_Balls
            // 
            this.groupBox_Balls.Controls.Add(this.textBox_SpecBalls);
            this.groupBox_Balls.Controls.Add(this.updateBalls);
            this.groupBox_Balls.Controls.Add(this.addBalls);
            this.groupBox_Balls.Controls.Add(this.deleteBalls);
            this.groupBox_Balls.Controls.Add(this.dataBalls);
            this.groupBox_Balls.Location = new System.Drawing.Point(467, 6);
            this.groupBox_Balls.Name = "groupBox_Balls";
            this.groupBox_Balls.Size = new System.Drawing.Size(236, 219);
            this.groupBox_Balls.TabIndex = 19;
            this.groupBox_Balls.TabStop = false;
            this.groupBox_Balls.Text = "Баллы";
            // 
            // textBox_SpecBalls
            // 
            this.textBox_SpecBalls.Location = new System.Drawing.Point(8, 20);
            this.textBox_SpecBalls.Name = "textBox_SpecBalls";
            this.textBox_SpecBalls.ReadOnly = true;
            this.textBox_SpecBalls.Size = new System.Drawing.Size(222, 20);
            this.textBox_SpecBalls.TabIndex = 26;
            // 
            // updateBalls
            // 
            this.updateBalls.Location = new System.Drawing.Point(84, 180);
            this.updateBalls.Name = "updateBalls";
            this.updateBalls.Size = new System.Drawing.Size(67, 23);
            this.updateBalls.TabIndex = 23;
            this.updateBalls.Text = "Изменить";
            this.updateBalls.UseVisualStyleBackColor = true;
            this.updateBalls.Click += new System.EventHandler(this.updateBalls_Click_1);
            // 
            // addBalls
            // 
            this.addBalls.Location = new System.Drawing.Point(8, 180);
            this.addBalls.Name = "addBalls";
            this.addBalls.Size = new System.Drawing.Size(67, 23);
            this.addBalls.TabIndex = 22;
            this.addBalls.Text = "Добавить";
            this.addBalls.UseVisualStyleBackColor = true;
            this.addBalls.Click += new System.EventHandler(this.addBalls_Click_1);
            // 
            // deleteBalls
            // 
            this.deleteBalls.Location = new System.Drawing.Point(163, 180);
            this.deleteBalls.Name = "deleteBalls";
            this.deleteBalls.Size = new System.Drawing.Size(67, 23);
            this.deleteBalls.TabIndex = 21;
            this.deleteBalls.Text = "Удалить";
            this.deleteBalls.UseVisualStyleBackColor = true;
            this.deleteBalls.Click += new System.EventHandler(this.deleteBalls_Click);
            // 
            // dataBalls
            // 
            this.dataBalls.AllowUserToAddRows = false;
            this.dataBalls.AllowUserToDeleteRows = false;
            this.dataBalls.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataBalls.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataBalls.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataBalls.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDD,
            this.IDS,
            this.STitle,
            this.IDDTitle,
            this.POINT});
            this.dataBalls.Location = new System.Drawing.Point(8, 50);
            this.dataBalls.Name = "dataBalls";
            this.dataBalls.ReadOnly = true;
            this.dataBalls.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataBalls.Size = new System.Drawing.Size(222, 124);
            this.dataBalls.TabIndex = 20;
            // 
            // IDD
            // 
            this.IDD.HeaderText = "IDD";
            this.IDD.Name = "IDD";
            this.IDD.ReadOnly = true;
            this.IDD.Visible = false;
            // 
            // IDS
            // 
            this.IDS.HeaderText = "IDS";
            this.IDS.Name = "IDS";
            this.IDS.ReadOnly = true;
            this.IDS.Visible = false;
            // 
            // STitle
            // 
            this.STitle.HeaderText = "STitle";
            this.STitle.Name = "STitle";
            this.STitle.ReadOnly = true;
            this.STitle.Visible = false;
            // 
            // IDDTitle
            // 
            this.IDDTitle.FillWeight = 109.8901F;
            this.IDDTitle.HeaderText = "Название дисциплины";
            this.IDDTitle.Name = "IDDTitle";
            this.IDDTitle.ReadOnly = true;
            // 
            // POINT
            // 
            this.POINT.FillWeight = 90.10989F;
            this.POINT.HeaderText = "Балл";
            this.POINT.Name = "POINT";
            this.POINT.ReadOnly = true;
            // 
            // updateSpec
            // 
            this.updateSpec.Location = new System.Drawing.Point(173, 226);
            this.updateSpec.Name = "updateSpec";
            this.updateSpec.Size = new System.Drawing.Size(141, 23);
            this.updateSpec.TabIndex = 10;
            this.updateSpec.Text = "Изм. специальность";
            this.updateSpec.UseVisualStyleBackColor = true;
            this.updateSpec.Click += new System.EventHandler(this.updateSpec_Click);
            // 
            // addSpecial
            // 
            this.addSpecial.Location = new System.Drawing.Point(173, 197);
            this.addSpecial.Name = "addSpecial";
            this.addSpecial.Size = new System.Drawing.Size(141, 23);
            this.addSpecial.TabIndex = 9;
            this.addSpecial.Text = "Доб. специальность";
            this.addSpecial.UseVisualStyleBackColor = true;
            this.addSpecial.Click += new System.EventHandler(this.addSpecial_Click);
            // 
            // groupSpeciality
            // 
            this.groupSpeciality.Controls.Add(this.cancelSpeciality);
            this.groupSpeciality.Controls.Add(this.saveSpeciality);
            this.groupSpeciality.Controls.Add(this.textBox_Speciality);
            this.groupSpeciality.Controls.Add(this.comboBox_Department);
            this.groupSpeciality.Location = new System.Drawing.Point(26, 336);
            this.groupSpeciality.Name = "groupSpeciality";
            this.groupSpeciality.Size = new System.Drawing.Size(677, 112);
            this.groupSpeciality.TabIndex = 8;
            this.groupSpeciality.TabStop = false;
            this.groupSpeciality.Text = "Специальность";
            // 
            // cancelSpeciality
            // 
            this.cancelSpeciality.Location = new System.Drawing.Point(88, 79);
            this.cancelSpeciality.Name = "cancelSpeciality";
            this.cancelSpeciality.Size = new System.Drawing.Size(75, 23);
            this.cancelSpeciality.TabIndex = 3;
            this.cancelSpeciality.Text = "Отмена";
            this.cancelSpeciality.UseVisualStyleBackColor = true;
            this.cancelSpeciality.Click += new System.EventHandler(this.cancelSpeciality_Click);
            // 
            // saveSpeciality
            // 
            this.saveSpeciality.Location = new System.Drawing.Point(7, 79);
            this.saveSpeciality.Name = "saveSpeciality";
            this.saveSpeciality.Size = new System.Drawing.Size(75, 23);
            this.saveSpeciality.TabIndex = 3;
            this.saveSpeciality.Text = "Сохранить";
            this.saveSpeciality.UseVisualStyleBackColor = true;
            this.saveSpeciality.Click += new System.EventHandler(this.saveSpeciality_Click);
            // 
            // textBox_Speciality
            // 
            this.textBox_Speciality.Location = new System.Drawing.Point(7, 51);
            this.textBox_Speciality.Name = "textBox_Speciality";
            this.textBox_Speciality.Size = new System.Drawing.Size(631, 20);
            this.textBox_Speciality.TabIndex = 1;
            // 
            // comboBox_Department
            // 
            this.comboBox_Department.FormattingEnabled = true;
            this.comboBox_Department.Location = new System.Drawing.Point(7, 20);
            this.comboBox_Department.Name = "comboBox_Department";
            this.comboBox_Department.Size = new System.Drawing.Size(631, 21);
            this.comboBox_Department.TabIndex = 0;
            // 
            // updateDepartment
            // 
            this.updateDepartment.Location = new System.Drawing.Point(26, 225);
            this.updateDepartment.Name = "updateDepartment";
            this.updateDepartment.Size = new System.Drawing.Size(141, 23);
            this.updateDepartment.TabIndex = 7;
            this.updateDepartment.Text = "Изменить кафедру";
            this.updateDepartment.UseVisualStyleBackColor = true;
            this.updateDepartment.Click += new System.EventHandler(this.updateDepartment_Click);
            // 
            // addDepartment
            // 
            this.addDepartment.Location = new System.Drawing.Point(26, 196);
            this.addDepartment.Name = "addDepartment";
            this.addDepartment.Size = new System.Drawing.Size(141, 23);
            this.addDepartment.TabIndex = 6;
            this.addDepartment.Text = "Добавить кафедру";
            this.addDepartment.UseVisualStyleBackColor = true;
            this.addDepartment.Click += new System.EventHandler(this.addDepartment_Click);
            // 
            // groupDepartment
            // 
            this.groupDepartment.Controls.Add(this.cancelDepartment);
            this.groupDepartment.Controls.Add(this.saveDepartment);
            this.groupDepartment.Controls.Add(this.textBox_Department);
            this.groupDepartment.Location = new System.Drawing.Point(26, 254);
            this.groupDepartment.Name = "groupDepartment";
            this.groupDepartment.Size = new System.Drawing.Size(677, 76);
            this.groupDepartment.TabIndex = 5;
            this.groupDepartment.TabStop = false;
            this.groupDepartment.Text = "Кафедра";
            // 
            // cancelDepartment
            // 
            this.cancelDepartment.Location = new System.Drawing.Point(88, 45);
            this.cancelDepartment.Name = "cancelDepartment";
            this.cancelDepartment.Size = new System.Drawing.Size(75, 23);
            this.cancelDepartment.TabIndex = 2;
            this.cancelDepartment.Text = "Отмена";
            this.cancelDepartment.UseVisualStyleBackColor = true;
            this.cancelDepartment.Click += new System.EventHandler(this.cancelDepartment_Click);
            // 
            // saveDepartment
            // 
            this.saveDepartment.Location = new System.Drawing.Point(7, 45);
            this.saveDepartment.Name = "saveDepartment";
            this.saveDepartment.Size = new System.Drawing.Size(75, 23);
            this.saveDepartment.TabIndex = 1;
            this.saveDepartment.Text = "Сохранить";
            this.saveDepartment.UseVisualStyleBackColor = true;
            this.saveDepartment.Click += new System.EventHandler(this.saveDepartment_Click);
            // 
            // textBox_Department
            // 
            this.textBox_Department.Location = new System.Drawing.Point(7, 19);
            this.textBox_Department.Name = "textBox_Department";
            this.textBox_Department.Size = new System.Drawing.Size(631, 20);
            this.textBox_Department.TabIndex = 0;
            // 
            // updateTree
            // 
            this.updateTree.Location = new System.Drawing.Point(320, 196);
            this.updateTree.Name = "updateTree";
            this.updateTree.Size = new System.Drawing.Size(141, 23);
            this.updateTree.TabIndex = 4;
            this.updateTree.Text = "Обновить";
            this.updateTree.UseVisualStyleBackColor = true;
            this.updateTree.Click += new System.EventHandler(this.updateTree_Click);
            // 
            // deleteSpeciality
            // 
            this.deleteSpeciality.Location = new System.Drawing.Point(173, 167);
            this.deleteSpeciality.Name = "deleteSpeciality";
            this.deleteSpeciality.Size = new System.Drawing.Size(141, 23);
            this.deleteSpeciality.TabIndex = 3;
            this.deleteSpeciality.Text = "Удалить специальность";
            this.deleteSpeciality.UseVisualStyleBackColor = true;
            this.deleteSpeciality.Click += new System.EventHandler(this.deleteSpeciality_Click);
            // 
            // deleteDepartment
            // 
            this.deleteDepartment.Location = new System.Drawing.Point(26, 167);
            this.deleteDepartment.Name = "deleteDepartment";
            this.deleteDepartment.Size = new System.Drawing.Size(141, 23);
            this.deleteDepartment.TabIndex = 1;
            this.deleteDepartment.Text = "Удалить кафедру";
            this.deleteDepartment.UseVisualStyleBackColor = true;
            this.deleteDepartment.Click += new System.EventHandler(this.deleteDepartment_Click);
            // 
            // treeDepartment
            // 
            this.treeDepartment.Location = new System.Drawing.Point(26, 6);
            this.treeDepartment.Name = "treeDepartment";
            this.treeDepartment.Size = new System.Drawing.Size(435, 155);
            this.treeDepartment.TabIndex = 0;
            this.treeDepartment.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeDepartment_AfterSelect);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.obnovaPLACES);
            this.tabPage2.Controls.Add(this.deletePLACES);
            this.tabPage2.Controls.Add(this.updatePLACES);
            this.tabPage2.Controls.Add(this.insertPLACES);
            this.tabPage2.Controls.Add(this.PLACESBOX);
            this.tabPage2.Controls.Add(this.dataPlaces);
            this.tabPage2.Controls.Add(this.treePlaces);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(722, 456);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Места";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // obnovaPLACES
            // 
            this.obnovaPLACES.Location = new System.Drawing.Point(588, 281);
            this.obnovaPLACES.Name = "obnovaPLACES";
            this.obnovaPLACES.Size = new System.Drawing.Size(128, 23);
            this.obnovaPLACES.TabIndex = 7;
            this.obnovaPLACES.Text = "Обновить";
            this.obnovaPLACES.UseVisualStyleBackColor = true;
            this.obnovaPLACES.Click += new System.EventHandler(this.obnovaPLACES_Click);
            // 
            // deletePLACES
            // 
            this.deletePLACES.Location = new System.Drawing.Point(274, 281);
            this.deletePLACES.Name = "deletePLACES";
            this.deletePLACES.Size = new System.Drawing.Size(128, 23);
            this.deletePLACES.TabIndex = 6;
            this.deletePLACES.Text = "Удалить";
            this.deletePLACES.UseVisualStyleBackColor = true;
            this.deletePLACES.Click += new System.EventHandler(this.deletePLACES_Click);
            // 
            // updatePLACES
            // 
            this.updatePLACES.Location = new System.Drawing.Point(140, 281);
            this.updatePLACES.Name = "updatePLACES";
            this.updatePLACES.Size = new System.Drawing.Size(128, 23);
            this.updatePLACES.TabIndex = 5;
            this.updatePLACES.Text = "Изменить";
            this.updatePLACES.UseVisualStyleBackColor = true;
            this.updatePLACES.Click += new System.EventHandler(this.updatePLACES_Click);
            // 
            // insertPLACES
            // 
            this.insertPLACES.Location = new System.Drawing.Point(6, 282);
            this.insertPLACES.Name = "insertPLACES";
            this.insertPLACES.Size = new System.Drawing.Size(128, 23);
            this.insertPLACES.TabIndex = 4;
            this.insertPLACES.Text = "Добавить";
            this.insertPLACES.UseVisualStyleBackColor = true;
            this.insertPLACES.Click += new System.EventHandler(this.insertPLACES_Click);
            // 
            // PLACESBOX
            // 
            this.PLACESBOX.Controls.Add(this.textBox_PLACES_SPEC);
            this.PLACESBOX.Controls.Add(this.savePLACES);
            this.PLACESBOX.Controls.Add(this.otmenaPLACES);
            this.PLACESBOX.Controls.Add(this.label5);
            this.PLACESBOX.Controls.Add(this.label4);
            this.PLACESBOX.Controls.Add(this.label3);
            this.PLACESBOX.Controls.Add(this.label2);
            this.PLACESBOX.Controls.Add(this.textBox_PLACES_NUMB);
            this.PLACESBOX.Controls.Add(this.comboBox_PLACES_BASIS);
            this.PLACESBOX.Controls.Add(this.comboBox_PLACES_FORM);
            this.PLACESBOX.Location = new System.Drawing.Point(6, 311);
            this.PLACESBOX.Name = "PLACESBOX";
            this.PLACESBOX.Size = new System.Drawing.Size(709, 135);
            this.PLACESBOX.TabIndex = 3;
            this.PLACESBOX.TabStop = false;
            this.PLACESBOX.Text = "Редактирование информации";
            // 
            // textBox_PLACES_SPEC
            // 
            this.textBox_PLACES_SPEC.Location = new System.Drawing.Point(247, 23);
            this.textBox_PLACES_SPEC.Name = "textBox_PLACES_SPEC";
            this.textBox_PLACES_SPEC.ReadOnly = true;
            this.textBox_PLACES_SPEC.Size = new System.Drawing.Size(234, 20);
            this.textBox_PLACES_SPEC.TabIndex = 10;
            // 
            // savePLACES
            // 
            this.savePLACES.Location = new System.Drawing.Point(5, 106);
            this.savePLACES.Name = "savePLACES";
            this.savePLACES.Size = new System.Drawing.Size(128, 23);
            this.savePLACES.TabIndex = 9;
            this.savePLACES.Text = "Сохранить";
            this.savePLACES.UseVisualStyleBackColor = true;
            this.savePLACES.Click += new System.EventHandler(this.savePLACES_Click);
            // 
            // otmenaPLACES
            // 
            this.otmenaPLACES.Location = new System.Drawing.Point(558, 106);
            this.otmenaPLACES.Name = "otmenaPLACES";
            this.otmenaPLACES.Size = new System.Drawing.Size(128, 23);
            this.otmenaPLACES.TabIndex = 8;
            this.otmenaPLACES.Text = "Отменить";
            this.otmenaPLACES.UseVisualStyleBackColor = true;
            this.otmenaPLACES.Click += new System.EventHandler(this.otmenaPLACES_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(535, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Количество мест:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(309, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Основа обучения:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Форма обучения:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(139, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Специальность";
            // 
            // textBox_PLACES_NUMB
            // 
            this.textBox_PLACES_NUMB.Location = new System.Drawing.Point(477, 75);
            this.textBox_PLACES_NUMB.Name = "textBox_PLACES_NUMB";
            this.textBox_PLACES_NUMB.Size = new System.Drawing.Size(209, 20);
            this.textBox_PLACES_NUMB.TabIndex = 3;
            // 
            // comboBox_PLACES_BASIS
            // 
            this.comboBox_PLACES_BASIS.FormattingEnabled = true;
            this.comboBox_PLACES_BASIS.Location = new System.Drawing.Point(247, 74);
            this.comboBox_PLACES_BASIS.Name = "comboBox_PLACES_BASIS";
            this.comboBox_PLACES_BASIS.Size = new System.Drawing.Size(209, 21);
            this.comboBox_PLACES_BASIS.TabIndex = 2;
            // 
            // comboBox_PLACES_FORM
            // 
            this.comboBox_PLACES_FORM.FormattingEnabled = true;
            this.comboBox_PLACES_FORM.Location = new System.Drawing.Point(5, 74);
            this.comboBox_PLACES_FORM.Name = "comboBox_PLACES_FORM";
            this.comboBox_PLACES_FORM.Size = new System.Drawing.Size(209, 21);
            this.comboBox_PLACES_FORM.TabIndex = 1;
            // 
            // dataPlaces
            // 
            this.dataPlaces.AllowUserToAddRows = false;
            this.dataPlaces.AllowUserToDeleteRows = false;
            this.dataPlaces.AllowUserToResizeColumns = false;
            this.dataPlaces.AllowUserToResizeRows = false;
            this.dataPlaces.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataPlaces.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataPlaces.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataPlaces.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDFT,
            this.IDBT,
            this.IDSPEC,
            this.TitleFT,
            this.TItleBT,
            this.NUM});
            this.dataPlaces.Location = new System.Drawing.Point(6, 150);
            this.dataPlaces.Name = "dataPlaces";
            this.dataPlaces.ReadOnly = true;
            this.dataPlaces.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataPlaces.Size = new System.Drawing.Size(710, 123);
            this.dataPlaces.TabIndex = 2;
            // 
            // IDFT
            // 
            this.IDFT.HeaderText = "IDFT";
            this.IDFT.Name = "IDFT";
            this.IDFT.ReadOnly = true;
            this.IDFT.Visible = false;
            // 
            // IDBT
            // 
            this.IDBT.HeaderText = "IDBT";
            this.IDBT.Name = "IDBT";
            this.IDBT.ReadOnly = true;
            this.IDBT.Visible = false;
            // 
            // IDSPEC
            // 
            this.IDSPEC.HeaderText = "IDSPEC";
            this.IDSPEC.Name = "IDSPEC";
            this.IDSPEC.ReadOnly = true;
            this.IDSPEC.Visible = false;
            // 
            // TitleFT
            // 
            this.TitleFT.HeaderText = "Форма";
            this.TitleFT.Name = "TitleFT";
            this.TitleFT.ReadOnly = true;
            // 
            // TItleBT
            // 
            this.TItleBT.HeaderText = "Основа";
            this.TItleBT.Name = "TItleBT";
            this.TItleBT.ReadOnly = true;
            // 
            // NUM
            // 
            this.NUM.HeaderText = "Кол-во мест";
            this.NUM.Name = "NUM";
            this.NUM.ReadOnly = true;
            // 
            // treePlaces
            // 
            this.treePlaces.Location = new System.Drawing.Point(6, 6);
            this.treePlaces.Name = "treePlaces";
            this.treePlaces.Size = new System.Drawing.Size(710, 138);
            this.treePlaces.TabIndex = 1;
            this.treePlaces.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treePlaces_AfterSelect);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.modAchieve);
            this.tabPage3.Controls.Add(this.groupBox_EntrantPoint);
            this.tabPage3.Controls.Add(this.groupBox_EntrAchieve);
            this.tabPage3.Controls.Add(this.upEnt);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.delEnt);
            this.tabPage3.Controls.Add(this.addEnt);
            this.tabPage3.Controls.Add(this.dataEntrant);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(722, 456);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Абитуриент";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(370, 205);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(346, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Изменить баллы";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // modAchieve
            // 
            this.modAchieve.Location = new System.Drawing.Point(4, 205);
            this.modAchieve.Name = "modAchieve";
            this.modAchieve.Size = new System.Drawing.Size(343, 23);
            this.modAchieve.TabIndex = 8;
            this.modAchieve.Text = "Изменить достижения";
            this.modAchieve.UseVisualStyleBackColor = true;
            this.modAchieve.Click += new System.EventHandler(this.modAchieve_Click);
            // 
            // groupBox_EntrantPoint
            // 
            this.groupBox_EntrantPoint.Controls.Add(this.button3);
            this.groupBox_EntrantPoint.Controls.Add(this.updatePoint);
            this.groupBox_EntrantPoint.Controls.Add(this.addPoint);
            this.groupBox_EntrantPoint.Controls.Add(this.deletePoint);
            this.groupBox_EntrantPoint.Controls.Add(this.dataPointEntrant);
            this.groupBox_EntrantPoint.Location = new System.Drawing.Point(370, 236);
            this.groupBox_EntrantPoint.Name = "groupBox_EntrantPoint";
            this.groupBox_EntrantPoint.Size = new System.Drawing.Size(346, 210);
            this.groupBox_EntrantPoint.TabIndex = 7;
            this.groupBox_EntrantPoint.TabStop = false;
            this.groupBox_EntrantPoint.Text = "Баллы абитуриента";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(250, 173);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "Отмена";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // updatePoint
            // 
            this.updatePoint.Location = new System.Drawing.Point(88, 173);
            this.updatePoint.Name = "updatePoint";
            this.updatePoint.Size = new System.Drawing.Size(75, 23);
            this.updatePoint.TabIndex = 3;
            this.updatePoint.Text = "Изменить";
            this.updatePoint.UseVisualStyleBackColor = true;
            this.updatePoint.Click += new System.EventHandler(this.updatePoint_Click);
            // 
            // addPoint
            // 
            this.addPoint.Location = new System.Drawing.Point(7, 173);
            this.addPoint.Name = "addPoint";
            this.addPoint.Size = new System.Drawing.Size(75, 23);
            this.addPoint.TabIndex = 2;
            this.addPoint.Text = "Добавить";
            this.addPoint.UseVisualStyleBackColor = true;
            this.addPoint.Click += new System.EventHandler(this.addPoint_Click);
            // 
            // deletePoint
            // 
            this.deletePoint.Location = new System.Drawing.Point(169, 173);
            this.deletePoint.Name = "deletePoint";
            this.deletePoint.Size = new System.Drawing.Size(75, 23);
            this.deletePoint.TabIndex = 1;
            this.deletePoint.Text = "Удалить";
            this.deletePoint.UseVisualStyleBackColor = true;
            this.deletePoint.Click += new System.EventHandler(this.deletePoint_Click);
            // 
            // dataPointEntrant
            // 
            this.dataPointEntrant.AllowUserToAddRows = false;
            this.dataPointEntrant.AllowUserToDeleteRows = false;
            this.dataPointEntrant.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataPointEntrant.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataPointEntrant.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDEntrant,
            this.IDDiscipline,
            this.TitleDiscipline,
            this.PointD});
            this.dataPointEntrant.Location = new System.Drawing.Point(7, 20);
            this.dataPointEntrant.Name = "dataPointEntrant";
            this.dataPointEntrant.ReadOnly = true;
            this.dataPointEntrant.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataPointEntrant.Size = new System.Drawing.Size(333, 147);
            this.dataPointEntrant.TabIndex = 0;
            this.dataPointEntrant.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataPointEntrant_CellClick);
            // 
            // IDEntrant
            // 
            this.IDEntrant.HeaderText = "IDEntrant";
            this.IDEntrant.Name = "IDEntrant";
            this.IDEntrant.ReadOnly = true;
            this.IDEntrant.Visible = false;
            // 
            // IDDiscipline
            // 
            this.IDDiscipline.HeaderText = "IDDiscipline";
            this.IDDiscipline.Name = "IDDiscipline";
            this.IDDiscipline.ReadOnly = true;
            this.IDDiscipline.Visible = false;
            // 
            // TitleDiscipline
            // 
            this.TitleDiscipline.HeaderText = "Дисциплина";
            this.TitleDiscipline.Name = "TitleDiscipline";
            this.TitleDiscipline.ReadOnly = true;
            // 
            // PointD
            // 
            this.PointD.HeaderText = "Баллы";
            this.PointD.Name = "PointD";
            this.PointD.ReadOnly = true;
            // 
            // groupBox_EntrAchieve
            // 
            this.groupBox_EntrAchieve.Controls.Add(this.button_DelAchieveOfEntrant);
            this.groupBox_EntrAchieve.Controls.Add(this.button12);
            this.groupBox_EntrAchieve.Controls.Add(this.dataAchieveOfEntrant);
            this.groupBox_EntrAchieve.Controls.Add(this.textBox1);
            this.groupBox_EntrAchieve.Controls.Add(this.comboBox_RealAchieve);
            this.groupBox_EntrAchieve.Controls.Add(this.updateToEntrantAc);
            this.groupBox_EntrAchieve.Location = new System.Drawing.Point(3, 236);
            this.groupBox_EntrAchieve.Name = "groupBox_EntrAchieve";
            this.groupBox_EntrAchieve.Size = new System.Drawing.Size(343, 210);
            this.groupBox_EntrAchieve.TabIndex = 6;
            this.groupBox_EntrAchieve.TabStop = false;
            this.groupBox_EntrAchieve.Text = "Достижеия абитуриента";
            // 
            // button_DelAchieveOfEntrant
            // 
            this.button_DelAchieveOfEntrant.Location = new System.Drawing.Point(87, 173);
            this.button_DelAchieveOfEntrant.Name = "button_DelAchieveOfEntrant";
            this.button_DelAchieveOfEntrant.Size = new System.Drawing.Size(75, 23);
            this.button_DelAchieveOfEntrant.TabIndex = 10;
            this.button_DelAchieveOfEntrant.Text = "Удалить";
            this.button_DelAchieveOfEntrant.UseVisualStyleBackColor = true;
            this.button_DelAchieveOfEntrant.Click += new System.EventHandler(this.button_DelAchieveOfEntrant_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(261, 173);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 12;
            this.button12.Text = "Отмена";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // dataAchieveOfEntrant
            // 
            this.dataAchieveOfEntrant.AllowUserToAddRows = false;
            this.dataAchieveOfEntrant.AllowUserToDeleteRows = false;
            this.dataAchieveOfEntrant.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataAchieveOfEntrant.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataAchieveOfEntrant.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataAchieveOfEntrant.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDac,
            this.IDEN,
            this.NAMEE,
            this.poii});
            this.dataAchieveOfEntrant.Location = new System.Drawing.Point(6, 17);
            this.dataAchieveOfEntrant.Name = "dataAchieveOfEntrant";
            this.dataAchieveOfEntrant.ReadOnly = true;
            this.dataAchieveOfEntrant.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataAchieveOfEntrant.Size = new System.Drawing.Size(330, 123);
            this.dataAchieveOfEntrant.TabIndex = 11;
            this.dataAchieveOfEntrant.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // IDac
            // 
            this.IDac.HeaderText = "IDac";
            this.IDac.Name = "IDac";
            this.IDac.ReadOnly = true;
            this.IDac.Visible = false;
            // 
            // IDEN
            // 
            this.IDEN.HeaderText = "IDEN";
            this.IDEN.Name = "IDEN";
            this.IDEN.ReadOnly = true;
            this.IDEN.Visible = false;
            // 
            // NAMEE
            // 
            this.NAMEE.HeaderText = "Достижение";
            this.NAMEE.Name = "NAMEE";
            this.NAMEE.ReadOnly = true;
            // 
            // poii
            // 
            this.poii.HeaderText = "Балл";
            this.poii.Name = "poii";
            this.poii.ReadOnly = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(127, 173);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(13, 20);
            this.textBox1.TabIndex = 10;
            this.textBox1.Visible = false;
            // 
            // comboBox_RealAchieve
            // 
            this.comboBox_RealAchieve.FormattingEnabled = true;
            this.comboBox_RealAchieve.Location = new System.Drawing.Point(7, 146);
            this.comboBox_RealAchieve.Name = "comboBox_RealAchieve";
            this.comboBox_RealAchieve.Size = new System.Drawing.Size(306, 21);
            this.comboBox_RealAchieve.TabIndex = 9;
            // 
            // updateToEntrantAc
            // 
            this.updateToEntrantAc.Location = new System.Drawing.Point(6, 173);
            this.updateToEntrantAc.Name = "updateToEntrantAc";
            this.updateToEntrantAc.Size = new System.Drawing.Size(75, 23);
            this.updateToEntrantAc.TabIndex = 8;
            this.updateToEntrantAc.Text = "Добавить выбранное";
            this.updateToEntrantAc.UseVisualStyleBackColor = true;
            this.updateToEntrantAc.Click += new System.EventHandler(this.updateToEntrantAc_Click);
            // 
            // upEnt
            // 
            this.upEnt.Location = new System.Drawing.Point(133, 176);
            this.upEnt.Name = "upEnt";
            this.upEnt.Size = new System.Drawing.Size(88, 23);
            this.upEnt.TabIndex = 3;
            this.upEnt.Text = "Изменить";
            this.upEnt.UseVisualStyleBackColor = true;
            this.upEnt.Click += new System.EventHandler(this.upEnt_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(641, 488);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Обновить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // delEnt
            // 
            this.delEnt.Location = new System.Drawing.Point(261, 176);
            this.delEnt.Name = "delEnt";
            this.delEnt.Size = new System.Drawing.Size(88, 23);
            this.delEnt.TabIndex = 4;
            this.delEnt.Text = "Удалить";
            this.delEnt.UseVisualStyleBackColor = true;
            this.delEnt.Click += new System.EventHandler(this.delEnt_Click);
            // 
            // addEnt
            // 
            this.addEnt.Location = new System.Drawing.Point(4, 176);
            this.addEnt.Name = "addEnt";
            this.addEnt.Size = new System.Drawing.Size(88, 23);
            this.addEnt.TabIndex = 2;
            this.addEnt.Text = "Добавить";
            this.addEnt.UseVisualStyleBackColor = true;
            this.addEnt.Click += new System.EventHandler(this.addEnt_Click);
            // 
            // dataEntrant
            // 
            this.dataEntrant.AllowUserToAddRows = false;
            this.dataEntrant.AllowUserToDeleteRows = false;
            this.dataEntrant.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataEntrant.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataEntrant.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataEntrant.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Sur,
            this.INAME,
            this.Pat,
            this.Pasp,
            this.Adr,
            this.DBer,
            this.Con,
            this.Edu,
            this.Host});
            this.dataEntrant.Location = new System.Drawing.Point(4, 4);
            this.dataEntrant.MultiSelect = false;
            this.dataEntrant.Name = "dataEntrant";
            this.dataEntrant.ReadOnly = true;
            this.dataEntrant.RowTemplate.ReadOnly = true;
            this.dataEntrant.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataEntrant.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataEntrant.Size = new System.Drawing.Size(712, 167);
            this.dataEntrant.TabIndex = 0;
            this.dataEntrant.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataEntrant_CellClick);
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // Sur
            // 
            this.Sur.HeaderText = "Фамилия";
            this.Sur.Name = "Sur";
            this.Sur.ReadOnly = true;
            // 
            // INAME
            // 
            this.INAME.HeaderText = "Имя";
            this.INAME.Name = "INAME";
            this.INAME.ReadOnly = true;
            // 
            // Pat
            // 
            this.Pat.HeaderText = "Отчество";
            this.Pat.Name = "Pat";
            this.Pat.ReadOnly = true;
            // 
            // Pasp
            // 
            this.Pasp.HeaderText = "Паспорт";
            this.Pasp.Name = "Pasp";
            this.Pasp.ReadOnly = true;
            // 
            // Adr
            // 
            this.Adr.HeaderText = "Адрес";
            this.Adr.Name = "Adr";
            this.Adr.ReadOnly = true;
            // 
            // DBer
            // 
            this.DBer.HeaderText = "Дата рождения";
            this.DBer.Name = "DBer";
            this.DBer.ReadOnly = true;
            // 
            // Con
            // 
            this.Con.HeaderText = "Контакт";
            this.Con.Name = "Con";
            this.Con.ReadOnly = true;
            // 
            // Edu
            // 
            this.Edu.HeaderText = "Пред обр";
            this.Edu.Name = "Edu";
            this.Edu.ReadOnly = true;
            // 
            // Host
            // 
            this.Host.HeaderText = "Общежитие";
            this.Host.Name = "Host";
            this.Host.ReadOnly = true;
            this.Host.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Host.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.delStat);
            this.tabPage4.Controls.Add(this.updatButton);
            this.tabPage4.Controls.Add(this.addStat);
            this.tabPage4.Controls.Add(this.button4);
            this.tabPage4.Controls.Add(this.dataEntrant2);
            this.tabPage4.Controls.Add(this.dataState);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(722, 456);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Заявления абитуриентов";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // delStat
            // 
            this.delStat.Location = new System.Drawing.Point(168, 427);
            this.delStat.Name = "delStat";
            this.delStat.Size = new System.Drawing.Size(75, 23);
            this.delStat.TabIndex = 7;
            this.delStat.Text = "Удалить";
            this.delStat.UseVisualStyleBackColor = true;
            this.delStat.Click += new System.EventHandler(this.delStat_Click);
            // 
            // updatButton
            // 
            this.updatButton.Location = new System.Drawing.Point(87, 427);
            this.updatButton.Name = "updatButton";
            this.updatButton.Size = new System.Drawing.Size(75, 23);
            this.updatButton.TabIndex = 6;
            this.updatButton.Text = "Изменить";
            this.updatButton.UseVisualStyleBackColor = true;
            this.updatButton.Click += new System.EventHandler(this.updatButton_Click);
            // 
            // addStat
            // 
            this.addStat.Location = new System.Drawing.Point(6, 427);
            this.addStat.Name = "addStat";
            this.addStat.Size = new System.Drawing.Size(75, 23);
            this.addStat.TabIndex = 5;
            this.addStat.Text = "Добавить";
            this.addStat.UseVisualStyleBackColor = true;
            this.addStat.Click += new System.EventHandler(this.addStat_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(643, 427);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Обновить";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dataEntrant2
            // 
            this.dataEntrant2.AllowUserToAddRows = false;
            this.dataEntrant2.AllowUserToDeleteRows = false;
            this.dataEntrant2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataEntrant2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataEntrant2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataEntrant2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID2,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewCheckBoxColumn1});
            this.dataEntrant2.Location = new System.Drawing.Point(3, 6);
            this.dataEntrant2.MultiSelect = false;
            this.dataEntrant2.Name = "dataEntrant2";
            this.dataEntrant2.ReadOnly = true;
            this.dataEntrant2.RowTemplate.ReadOnly = true;
            this.dataEntrant2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataEntrant2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataEntrant2.Size = new System.Drawing.Size(712, 238);
            this.dataEntrant2.TabIndex = 3;
            this.dataEntrant2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataEntrant2_CellClick);
            // 
            // ID2
            // 
            this.ID2.HeaderText = "ID";
            this.ID2.Name = "ID2";
            this.ID2.ReadOnly = true;
            this.ID2.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Паспорт";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Адрес";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Visible = false;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Дата рождения";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Visible = false;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Контакт";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Visible = false;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Пред обр";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Visible = false;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "Общежитие";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn1.Visible = false;
            // 
            // dataState
            // 
            this.dataState.AllowUserToAddRows = false;
            this.dataState.AllowUserToDeleteRows = false;
            this.dataState.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataState.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataState.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataState.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDStat,
            this.IDEntr,
            this.IDSpecial,
            this.IDForm,
            this.IDBasis,
            this.TitleSpec,
            this.TitleForm,
            this.TitleBas,
            this.Consent,
            this.OD});
            this.dataState.Location = new System.Drawing.Point(3, 262);
            this.dataState.Name = "dataState";
            this.dataState.ReadOnly = true;
            this.dataState.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataState.Size = new System.Drawing.Size(713, 159);
            this.dataState.TabIndex = 2;
            this.dataState.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataState_CellClick);
            // 
            // IDStat
            // 
            this.IDStat.HeaderText = "IDStat";
            this.IDStat.Name = "IDStat";
            this.IDStat.ReadOnly = true;
            this.IDStat.Visible = false;
            // 
            // IDEntr
            // 
            this.IDEntr.HeaderText = "IDEntr";
            this.IDEntr.Name = "IDEntr";
            this.IDEntr.ReadOnly = true;
            this.IDEntr.Visible = false;
            // 
            // IDSpecial
            // 
            this.IDSpecial.HeaderText = "IDSpecial";
            this.IDSpecial.Name = "IDSpecial";
            this.IDSpecial.ReadOnly = true;
            this.IDSpecial.Visible = false;
            // 
            // IDForm
            // 
            this.IDForm.HeaderText = "IDForm";
            this.IDForm.Name = "IDForm";
            this.IDForm.ReadOnly = true;
            this.IDForm.Visible = false;
            // 
            // IDBasis
            // 
            this.IDBasis.HeaderText = "IDBasis";
            this.IDBasis.Name = "IDBasis";
            this.IDBasis.ReadOnly = true;
            this.IDBasis.Visible = false;
            // 
            // TitleSpec
            // 
            this.TitleSpec.HeaderText = "Специальность";
            this.TitleSpec.Name = "TitleSpec";
            this.TitleSpec.ReadOnly = true;
            // 
            // TitleForm
            // 
            this.TitleForm.HeaderText = "Форма";
            this.TitleForm.Name = "TitleForm";
            this.TitleForm.ReadOnly = true;
            // 
            // TitleBas
            // 
            this.TitleBas.HeaderText = "Основа";
            this.TitleBas.Name = "TitleBas";
            this.TitleBas.ReadOnly = true;
            // 
            // Consent
            // 
            this.Consent.HeaderText = "Согласие";
            this.Consent.Name = "Consent";
            this.Consent.ReadOnly = true;
            this.Consent.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Consent.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // OD
            // 
            this.OD.HeaderText = "Оригинал.док";
            this.OD.Name = "OD";
            this.OD.ReadOnly = true;
            this.OD.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.OD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dataGridView_ACHIEVE);
            this.tabPage5.Controls.Add(this.button10);
            this.tabPage5.Controls.Add(this.groupBox_Achieve_5);
            this.tabPage5.Controls.Add(this.button7);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Controls.Add(this.groupBox_Discipline_5);
            this.tabPage5.Controls.Add(this.updateDiscipl);
            this.tabPage5.Controls.Add(this.addDiscipl);
            this.tabPage5.Controls.Add(this.deleteDisc);
            this.tabPage5.Controls.Add(this.listBox_Discipline);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(722, 456);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Дополнительно";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dataGridView_ACHIEVE
            // 
            this.dataGridView_ACHIEVE.AllowUserToAddRows = false;
            this.dataGridView_ACHIEVE.AllowUserToDeleteRows = false;
            this.dataGridView_ACHIEVE.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_ACHIEVE.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView_ACHIEVE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_ACHIEVE.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDdost,
            this.TitleDOST,
            this.PointDOST});
            this.dataGridView_ACHIEVE.Location = new System.Drawing.Point(24, 22);
            this.dataGridView_ACHIEVE.Name = "dataGridView_ACHIEVE";
            this.dataGridView_ACHIEVE.ReadOnly = true;
            this.dataGridView_ACHIEVE.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ACHIEVE.Size = new System.Drawing.Size(332, 303);
            this.dataGridView_ACHIEVE.TabIndex = 33;
            this.dataGridView_ACHIEVE.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // IDdost
            // 
            this.IDdost.HeaderText = "IDdost";
            this.IDdost.Name = "IDdost";
            this.IDdost.ReadOnly = true;
            this.IDdost.Visible = false;
            // 
            // TitleDOST
            // 
            this.TitleDOST.HeaderText = "Наименование";
            this.TitleDOST.Name = "TitleDOST";
            this.TitleDOST.ReadOnly = true;
            // 
            // PointDOST
            // 
            this.PointDOST.HeaderText = "Балл";
            this.PointDOST.Name = "PointDOST";
            this.PointDOST.ReadOnly = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(641, 488);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 30;
            this.button10.Text = "Обновить";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // groupBox_Achieve_5
            // 
            this.groupBox_Achieve_5.Controls.Add(this.button9);
            this.groupBox_Achieve_5.Controls.Add(this.button8);
            this.groupBox_Achieve_5.Controls.Add(this.poinBox);
            this.groupBox_Achieve_5.Controls.Add(this.dostBox);
            this.groupBox_Achieve_5.Location = new System.Drawing.Point(24, 364);
            this.groupBox_Achieve_5.Name = "groupBox_Achieve_5";
            this.groupBox_Achieve_5.Size = new System.Drawing.Size(332, 82);
            this.groupBox_Achieve_5.TabIndex = 25;
            this.groupBox_Achieve_5.TabStop = false;
            this.groupBox_Achieve_5.Text = "Достижение";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(146, 46);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 29;
            this.button9.Text = "Отмена";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(6, 46);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 28;
            this.button8.Text = "Сохранить";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // poinBox
            // 
            this.poinBox.Location = new System.Drawing.Point(248, 20);
            this.poinBox.Name = "poinBox";
            this.poinBox.Size = new System.Drawing.Size(54, 20);
            this.poinBox.TabIndex = 27;
            // 
            // dostBox
            // 
            this.dostBox.Location = new System.Drawing.Point(6, 20);
            this.dostBox.Name = "dostBox";
            this.dostBox.Size = new System.Drawing.Size(215, 20);
            this.dostBox.TabIndex = 26;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(178, 335);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(67, 23);
            this.button7.TabIndex = 24;
            this.button7.Text = "Удалить";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(105, 335);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(67, 23);
            this.button6.TabIndex = 23;
            this.button6.Text = "Изменить";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox_Discipline_5
            // 
            this.groupBox_Discipline_5.Controls.Add(this.textBox_Discipline);
            this.groupBox_Discipline_5.Controls.Add(this.otmenaDisci);
            this.groupBox_Discipline_5.Controls.Add(this.saveDisc);
            this.groupBox_Discipline_5.Location = new System.Drawing.Point(372, 364);
            this.groupBox_Discipline_5.Name = "groupBox_Discipline_5";
            this.groupBox_Discipline_5.Size = new System.Drawing.Size(330, 82);
            this.groupBox_Discipline_5.TabIndex = 22;
            this.groupBox_Discipline_5.TabStop = false;
            this.groupBox_Discipline_5.Text = "Дисциплина";
            // 
            // textBox_Discipline
            // 
            this.textBox_Discipline.Location = new System.Drawing.Point(7, 20);
            this.textBox_Discipline.Name = "textBox_Discipline";
            this.textBox_Discipline.Size = new System.Drawing.Size(299, 20);
            this.textBox_Discipline.TabIndex = 18;
            // 
            // otmenaDisci
            // 
            this.otmenaDisci.Location = new System.Drawing.Point(234, 53);
            this.otmenaDisci.Name = "otmenaDisci";
            this.otmenaDisci.Size = new System.Drawing.Size(72, 23);
            this.otmenaDisci.TabIndex = 17;
            this.otmenaDisci.Text = "Отмена";
            this.otmenaDisci.UseVisualStyleBackColor = true;
            this.otmenaDisci.Click += new System.EventHandler(this.otmenaDisci_Click_1);
            // 
            // saveDisc
            // 
            this.saveDisc.Location = new System.Drawing.Point(6, 53);
            this.saveDisc.Name = "saveDisc";
            this.saveDisc.Size = new System.Drawing.Size(73, 23);
            this.saveDisc.TabIndex = 17;
            this.saveDisc.Text = "Сохранить";
            this.saveDisc.UseVisualStyleBackColor = true;
            this.saveDisc.Click += new System.EventHandler(this.saveDisc_Click_1);
            // 
            // updateDiscipl
            // 
            this.updateDiscipl.Location = new System.Drawing.Point(445, 335);
            this.updateDiscipl.Name = "updateDiscipl";
            this.updateDiscipl.Size = new System.Drawing.Size(67, 23);
            this.updateDiscipl.TabIndex = 21;
            this.updateDiscipl.Text = "Изменить";
            this.updateDiscipl.UseVisualStyleBackColor = true;
            this.updateDiscipl.Click += new System.EventHandler(this.updateDiscipl_Click_1);
            // 
            // addDiscipl
            // 
            this.addDiscipl.Location = new System.Drawing.Point(372, 335);
            this.addDiscipl.Name = "addDiscipl";
            this.addDiscipl.Size = new System.Drawing.Size(67, 23);
            this.addDiscipl.TabIndex = 20;
            this.addDiscipl.Text = "Добавить";
            this.addDiscipl.UseVisualStyleBackColor = true;
            this.addDiscipl.Click += new System.EventHandler(this.addDiscipl_Click_1);
            // 
            // deleteDisc
            // 
            this.deleteDisc.Location = new System.Drawing.Point(518, 335);
            this.deleteDisc.Name = "deleteDisc";
            this.deleteDisc.Size = new System.Drawing.Size(67, 23);
            this.deleteDisc.TabIndex = 19;
            this.deleteDisc.Text = "Удалить";
            this.deleteDisc.UseVisualStyleBackColor = true;
            this.deleteDisc.Click += new System.EventHandler(this.deleteDisc_Click_1);
            // 
            // listBox_Discipline
            // 
            this.listBox_Discipline.FormattingEnabled = true;
            this.listBox_Discipline.Location = new System.Drawing.Point(372, 22);
            this.listBox_Discipline.Name = "listBox_Discipline";
            this.listBox_Discipline.Size = new System.Drawing.Size(331, 303);
            this.listBox_Discipline.TabIndex = 17;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(24, 335);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 2;
            this.button5.Text = "Добавить достижение";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // errorTitleDepart
            // 
            this.errorTitleDepart.ContainerControl = this;
            // 
            // errorComboDep
            // 
            this.errorComboDep.ContainerControl = this;
            // 
            // errorTitleSpec
            // 
            this.errorTitleSpec.ContainerControl = this;
            // 
            // errorDiscip
            // 
            this.errorDiscip.ContainerControl = this;
            // 
            // errorBalls1
            // 
            this.errorBalls1.ContainerControl = this;
            // 
            // notInfoBallsAdd
            // 
            this.notInfoBallsAdd.ContainerControl = this;
            // 
            // erFORMTRANING
            // 
            this.erFORMTRANING.ContainerControl = this;
            // 
            // erBASISTRANING
            // 
            this.erBASISTRANING.ContainerControl = this;
            // 
            // erNUMPLACES
            // 
            this.erNUMPLACES.ContainerControl = this;
            // 
            // erAC
            // 
            this.erAC.ContainerControl = this;
            // 
            // erPA
            // 
            this.erPA.ContainerControl = this;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(641, 177);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 13;
            this.button11.Text = "Обновить";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // DBComissionMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 499);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "DBComissionMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "БД \"Отборочная комиссия\"";
            this.Load += new System.EventHandler(this.DBComissionMain_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox_Balls.ResumeLayout(false);
            this.groupBox_Balls.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBalls)).EndInit();
            this.groupSpeciality.ResumeLayout(false);
            this.groupSpeciality.PerformLayout();
            this.groupDepartment.ResumeLayout(false);
            this.groupDepartment.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.PLACESBOX.ResumeLayout(false);
            this.PLACESBOX.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataPlaces)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox_EntrantPoint.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataPointEntrant)).EndInit();
            this.groupBox_EntrAchieve.ResumeLayout(false);
            this.groupBox_EntrAchieve.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataAchieveOfEntrant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataEntrant)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataEntrant2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataState)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ACHIEVE)).EndInit();
            this.groupBox_Achieve_5.ResumeLayout(false);
            this.groupBox_Achieve_5.PerformLayout();
            this.groupBox_Discipline_5.ResumeLayout(false);
            this.groupBox_Discipline_5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorTitleDepart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorComboDep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorTitleSpec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorDiscip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBalls1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notInfoBallsAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erFORMTRANING)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erBASISTRANING)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erNUMPLACES)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erAC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erPA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TreeView treeDepartment;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button deleteDepartment;
        private System.Windows.Forms.Button deleteSpeciality;
        private System.Windows.Forms.Button updateTree;
        private System.Windows.Forms.Button addDepartment;
        private System.Windows.Forms.GroupBox groupDepartment;
        private System.Windows.Forms.Button cancelDepartment;
        private System.Windows.Forms.Button saveDepartment;
        private System.Windows.Forms.TextBox textBox_Department;
        private System.Windows.Forms.ErrorProvider errorTitleDepart;
        private System.Windows.Forms.Button updateDepartment;
        private System.Windows.Forms.GroupBox groupSpeciality;
        private System.Windows.Forms.Button cancelSpeciality;
        private System.Windows.Forms.Button saveSpeciality;
        private System.Windows.Forms.TextBox textBox_Speciality;
        private System.Windows.Forms.ComboBox comboBox_Department;
        private System.Windows.Forms.ErrorProvider errorComboDep;
        private System.Windows.Forms.ErrorProvider errorTitleSpec;
        private System.Windows.Forms.Button updateSpec;
        private System.Windows.Forms.Button addSpecial;
        private System.Windows.Forms.ErrorProvider errorDiscip;
        private System.Windows.Forms.GroupBox groupBox_Balls;
        private System.Windows.Forms.Button modifBalls;
        private System.Windows.Forms.DataGridView dataBalls;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDD;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDS;
        private System.Windows.Forms.DataGridViewTextBoxColumn STitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDDTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn POINT;
        private System.Windows.Forms.Button updateBalls;
        private System.Windows.Forms.Button addBalls;
        private System.Windows.Forms.Button deleteBalls;
        private System.Windows.Forms.ErrorProvider errorBalls1;
        private System.Windows.Forms.ErrorProvider notInfoBallsAdd;
        private System.Windows.Forms.TextBox textBox_SpecBalls;
        private System.Windows.Forms.TreeView treePlaces;
        private System.Windows.Forms.DataGridView dataPlaces;
        private System.Windows.Forms.Button obnovaPLACES;
        private System.Windows.Forms.Button deletePLACES;
        private System.Windows.Forms.Button updatePLACES;
        private System.Windows.Forms.Button insertPLACES;
        private System.Windows.Forms.GroupBox PLACESBOX;
        private System.Windows.Forms.Button savePLACES;
        private System.Windows.Forms.Button otmenaPLACES;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_PLACES_NUMB;
        private System.Windows.Forms.ComboBox comboBox_PLACES_BASIS;
        private System.Windows.Forms.ComboBox comboBox_PLACES_FORM;
        private System.Windows.Forms.TextBox textBox_PLACES_SPEC;
        private System.Windows.Forms.ErrorProvider erFORMTRANING;
        private System.Windows.Forms.ErrorProvider erBASISTRANING;
        private System.Windows.Forms.ErrorProvider erNUMPLACES;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDFT;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDBT;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDSPEC;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleFT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TItleBT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NUM;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataEntrant;
        private System.Windows.Forms.Button delEnt;
        private System.Windows.Forms.Button upEnt;
        private System.Windows.Forms.Button addEnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sur;
        private System.Windows.Forms.DataGridViewTextBoxColumn INAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pasp;
        private System.Windows.Forms.DataGridViewTextBoxColumn Adr;
        private System.Windows.Forms.DataGridViewTextBoxColumn DBer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Con;
        private System.Windows.Forms.DataGridViewTextBoxColumn Edu;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Host;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox_EntrantPoint;
        private System.Windows.Forms.GroupBox groupBox_EntrAchieve;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataState;
        private System.Windows.Forms.Button updateToEntrantAc;
        private System.Windows.Forms.Button modAchieve;
        private System.Windows.Forms.DataGridView dataPointEntrant;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDEntrant;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDDiscipline;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleDiscipline;
        private System.Windows.Forms.DataGridViewTextBoxColumn PointD;
        private System.Windows.Forms.Button updatePoint;
        private System.Windows.Forms.Button addPoint;
        private System.Windows.Forms.Button deletePoint;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataEntrant2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button delStat;
        private System.Windows.Forms.Button updatButton;
        private System.Windows.Forms.Button addStat;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDStat;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDEntr;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDSpecial;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDForm;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDBasis;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleSpec;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleForm;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleBas;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Consent;
        private System.Windows.Forms.DataGridViewCheckBoxColumn OD;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox_Discipline_5;
        private System.Windows.Forms.TextBox textBox_Discipline;
        private System.Windows.Forms.Button otmenaDisci;
        private System.Windows.Forms.Button saveDisc;
        private System.Windows.Forms.Button updateDiscipl;
        private System.Windows.Forms.Button addDiscipl;
        private System.Windows.Forms.Button deleteDisc;
        private System.Windows.Forms.ListBox listBox_Discipline;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox_Achieve_5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox poinBox;
        private System.Windows.Forms.TextBox dostBox;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ErrorProvider erAC;
        private System.Windows.Forms.ErrorProvider erPA;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ComboBox comboBox_RealAchieve;
        private System.Windows.Forms.Button button_DelAchieveOfEntrant;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataAchieveOfEntrant;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDac;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDEN;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAMEE;
        private System.Windows.Forms.DataGridViewTextBoxColumn poii;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.DataGridView dataGridView_ACHIEVE;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDdost;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleDOST;
        private System.Windows.Forms.DataGridViewTextBoxColumn PointDOST;
        private System.Windows.Forms.Button button11;
    }
}

