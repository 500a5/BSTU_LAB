﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bddddd.DBClass;

namespace bddddd
{
    public partial class AddOrUpdateMINSCORE : Form
    {
        string titleSpeciality = "";
        string titleDiscipline = "";
        int timeBalls = -1;

        DepartmentDB department = new DepartmentDB();
        SpecialityDB speciality = new SpecialityDB();
        MinScoreDB minscore = new MinScoreDB();
        DisciplineDB discipline = new DisciplineDB();

        public AddOrUpdateMINSCORE(string s)
        {
            InitializeComponent();
            this.titleSpeciality = s;
            textBox_SPEC.Text = this.titleSpeciality;
        }

        public AddOrUpdateMINSCORE(string spec, string disc, int ball)
        {
            InitializeComponent();

            this.titleSpeciality = spec;
            this.titleDiscipline = disc;
            this.timeBalls = ball;

            textBox_SPEC.Text = this.titleSpeciality;
            textBox_BALLS.Text = this.timeBalls.ToString();
            comboBox_DICS.Items.Add(this.titleDiscipline);
            comboBox_DICS.SelectedIndex = comboBox_DICS.FindStringExact(this.titleDiscipline);

        }

        private void AddOrUpdateMINSCORE_Load(object sender, EventArgs e)
        {
            if (timeBalls == -1)
            {
                int idSp = speciality.search(titleSpeciality);
                showDisc(idSp);
            }
        }

        private void AddOrUpdateMINSCORE_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form ifrm = Application.OpenForms[0];
            ifrm.Show();
            this.Close();
        }

        private void updateThis()
        {
            int idSp = speciality.search(titleSpeciality); //ид специальности
            if (comboBox_DICS.SelectedIndex == -1)
            {
                errorProv.SetError(comboBox_DICS, "Не выбрана дисциплина!");
            }
            else
            {
                int idDisc = discipline.searchId(comboBox_DICS.Text); //ид дисциплины
                string sbal = textBox_BALLS.Text;
                if (sbal == "")
                {
                    errorProv.SetError(textBox_BALLS, "Балл не может отсутствовать!");
                }
                else
                {
                    int ibal = -1;
                    if (Int32.TryParse(sbal, out ibal))
                    {
                        if (ibal > 100)
                            errorProv.SetError(textBox_BALLS, "Балл не может быть больше 100!");
                        else if (ibal < 0)
                            errorProv.SetError(textBox_BALLS, "Балл не может быть меньше 0!");
                        else
                        {
                            if (minscore.insertInto(ibal, idDisc, idSp))
                            {
                                MessageBox.Show("Запись добавлена!", "Успешно");
                                Form ifrm = Application.OpenForms[0];
                                ifrm.Show();
                                this.Close();
                            }
                        }
                    }
                    else
                    {
                        errorProv.SetError(textBox_BALLS, "Не число!");
                    }
                }
            }
        }

        private void insertThie()
        {
            int idSp = speciality.search(titleSpeciality); //ид специальности
            int idDisc = discipline.searchId(comboBox_DICS.Text); //ид дисциплины
            string sbal = textBox_BALLS.Text;
            if (sbal == "")
            {
                errorProv.SetError(textBox_BALLS, "Балл не может отсутствовать!");
            }
            else
            {
                int ibal = -1;
                if (Int32.TryParse(sbal, out ibal))
                {
                    if (ibal > 100)
                        errorProv.SetError(textBox_BALLS, "Балл не может быть больше 100!");
                    else if (ibal < 0)
                        errorProv.SetError(textBox_BALLS, "Балл не может быть меньше 0!");
                    else
                    {
                        if (minscore.updateInfo(ibal, idSp, idDisc))
                        {
                            MessageBox.Show("Запись изменена!", "Успешно");
                            Form ifrm = Application.OpenForms[0];
                            ifrm.Show();
                            this.Close();
                        }
                    }
                }
                else
                {
                    errorProv.SetError(textBox_BALLS, "Не число!");
                }
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if(timeBalls == -1)
            {
                updateThis();
            }
            else
            {
                insertThie();
            }
        }

        //вернет индекс дисциплины, если такая есть для специальнсти
        private int minSearch(int idSpec, string s)
        {
            List<string[]> lst = minscore.selectByID(idSpec); //получили конкретные баллы
            for (int i = 0; i < lst.Count; i++)
            {
                if (s == lst[i][3])
                    return Int32.Parse(lst[i][0]);
            }

            return -1;
        }

        //что можно добавить
        private void showDisc(int idSpec)
        {
            List<string[]> lst = discipline.selectAll(); //все дисциплины
            for (int i = 0; i < lst.Count; i++)
            {
                if (minSearch(idSpec, lst[i][0]) == -1)
                    comboBox_DICS.Items.Add(lst[i][0]);
            }
        }
    }
}
